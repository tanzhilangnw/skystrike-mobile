"""InputProvider: 统一输入抽象 (keyboard / touch 两个实现).

游戏逻辑只认统一输入事件:
  move    : (dx, dy) 移动向量, 范围 [-1, 1]
  bomb    : bool 本帧按下炸弹
  cycle   : bool 本帧按下切武器
  pause   : bool 本帧按下暂停
  confirm : bool 本帧按下确认 (菜单推进)
  back    : bool 本帧按下返回

两个实现:
  KeyboardInput : pygame.key.get_pressed() + KEYDOWN 事件
  TouchInput    : MOUSEBUTTONDOWN/MOTION/UP (手指拖拽) + 屏上按钮点按

平台检测 (单代码库, 零原生工具链):
  SK_INPUT=touch 环境变量强制触控 (headless 测试用)
  pygbag / Emscripten / Android 自动检测触控
  其余默认键盘
"""
import os
import platform
import sys

import pygame

# 逻辑坐标基准 (竖屏), 双端等比缩放
LOGICAL_W = 480
LOGICAL_H = 800

# 触控拖拽: 飞机跟随手指并带上移偏移 (避免手指遮住机身)
TOUCH_OFFSET_Y = 60


def detect_platform():
    """返回 'touch' 或 'keyboard'."""
    forced = os.environ.get('SK_INPUT', '').lower()
    if forced in ('touch', 'keyboard'):
        return forced
    # pygbag → Emscripten (WebAssembly), python-for-android → Android
    sysname = platform.system().lower()
    if sys.platform == 'emscripten' or sysname in ('emscripten', 'android', 'ios'):
        return 'touch'
    # pygame-ce 在 android 上 platform 可能仍是 Linux, 用 get_sdl 兜底
    try:
        if hasattr(pygame, 'get_sdl_version'):
            pass
    except Exception:
        pass
    return 'keyboard'


class InputProvider:
    """基类: 每帧产出统一输入字典."""

    kind = 'base'

    def __init__(self, game):
        self.game = game
        # 本帧一次性事件 (bomb/cycle/pause/confirm/back), 读取后清零
        self._pressed = {
            'bomb': False, 'cycle': False, 'pause': False,
            'confirm': False, 'back': False,
        }
        self._move = (0.0, 0.0)

    # ---- 事件入口 (run 循环调用) ----
    def handle_event(self, event):
        raise NotImplementedError

    # ---- 每帧轮询 (run 循环 _update 前调用) ----
    def poll(self):
        raise NotImplementedError

    # ---- 统一读取接口 (游戏逻辑调用) ----
    def get_move(self):
        return self._move

    def consume(self, name):
        """读取一次性事件并清零."""
        v = self._pressed.get(name, False)
        self._pressed[name] = False
        return v

    def _set(self, name):
        self._pressed[name] = True

    # ---- 触控 UI (仅 TouchInput 覆写) ----
    def draw_touch_ui(self, surface):
        pass

    def touch_hit(self, pos):
        """触控点按是否命中屏上按钮/菜单; 命中返回 True (已处理)."""
        return False


class KeyboardInput(InputProvider):
    """键盘实现: WASD/方向键移动, J/空格炸弹, K 切武器, Esc/P 暂停, 回车确认."""

    kind = 'keyboard'

    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return
        k = event.key
        if k in (pygame.K_j, pygame.K_SPACE):
            self._set('bomb')
        elif k in (pygame.K_k, pygame.K_TAB):
            self._set('cycle')
        elif k in (pygame.K_ESCAPE, pygame.K_p):
            self._set('pause')
        elif k in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self._set('confirm')
        elif k == pygame.K_BACKSPACE:
            self._set('back')

    def poll(self):
        keys = pygame.key.get_pressed()
        dx = 0.0
        dy = 0.0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= 1.0
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += 1.0
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            dy -= 1.0
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            dy += 1.0
        self._move = (dx, dy)


class TouchInput(InputProvider):
    """触控实现: 全屏拖拽移动 + 屏上按钮 (炸弹/切武器/暂停) + 菜单点按.

    屏上按钮簇 (固定右下, 半透明):
      bomb  : 右下大圆
      cycle : 右下小圆 (bomb 左上)
      pause : 右上小圆
    """

    kind = 'touch'

    # 按钮半径 (逻辑坐标)
    R_BOMB = 44
    R_CYCLE = 30
    R_PAUSE = 26

    def __init__(self, game):
        super().__init__(game)
        self._dragging = False
        self._finger_pos = None   # 当前手指逻辑坐标
        self._ship_target = None  # 飞机目标 (手指 + 上移偏移)

    # ---- 屏上按钮几何 (逻辑坐标) ----
    def _btn_bomb(self):
        return (LOGICAL_W - 64, LOGICAL_H - 96, self.R_BOMB)

    def _btn_cycle(self):
        return (LOGICAL_W - 132, LOGICAL_H - 60, self.R_CYCLE)

    def _btn_pause(self):
        return (LOGICAL_W - 44, 44, self.R_PAUSE)

    def _in_circle(self, pos, cx, cy, r):
        dx = pos[0] - cx
        dy = pos[1] - cy
        return dx * dx + dy * dy <= r * r

    # ---- 事件入口 ----
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = self._to_logical(event.pos)
            st = self.game.state
            if st == self.game.STATE_PLAYING:
                # 游戏内: 屏上按钮优先, 其余位置开始拖拽
                bx, by, br = self._btn_bomb()
                if self._in_circle(pos, bx, by, br):
                    self._set('bomb')
                    return
                bx, by, br = self._btn_cycle()
                if self._in_circle(pos, bx, by, br):
                    self._set('cycle')
                    return
                bx, by, br = self._btn_pause()
                if self._in_circle(pos, bx, by, br):
                    self._set('pause')
                    return
                self._dragging = True
                self._finger_pos = pos
                self._update_target()
            else:
                # 菜单/商店/设置/结算: 点按条目; 空白处兜底=confirm
                if self.touch_hit(pos):
                    return
                self._set('confirm')
        elif event.type == pygame.MOUSEMOTION and self._dragging:
            self._finger_pos = self._to_logical(event.pos)
            self._update_target()
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self._dragging = False
            self._finger_pos = None
            self._ship_target = None
            self._move = (0.0, 0.0)

    def _to_logical(self, pos):
        """屏幕坐标 → 逻辑坐标 (考虑等比缩放 + 黑边)."""
        surf = pygame.display.get_surface()
        if surf is None:
            return pos
        sw, sh = surf.get_size()
        scale = min(sw / LOGICAL_W, sh / LOGICAL_H)
        ox = (sw - LOGICAL_W * scale) / 2.0
        oy = (sh - LOGICAL_H * scale) / 2.0
        return ((pos[0] - ox) / scale, (pos[1] - oy) / scale)

    def _update_target(self):
        """飞机目标 = 手指 + 上移偏移."""
        if self._finger_pos is None:
            return
        fx, fy = self._finger_pos
        self._ship_target = (fx, fy - TOUCH_OFFSET_Y)

    # ---- 每帧轮询: 拖拽 → 移动向量 (朝目标) ----
    def poll(self):
        if not self._dragging or self._ship_target is None:
            self._move = (0.0, 0.0)
            return
        # 主玩家别名: self.player == self.players[0]
        ship = getattr(self.game, 'player', None)
        if ship is None or not getattr(ship, 'alive', False):
            self._move = (0.0, 0.0)
            return
        tx, ty = self._ship_target
        dx = tx - ship.x
        dy = ty - ship.y
        # 归一化到 [-1, 1], 死区 2px
        mx = 0.0
        my = 0.0
        if abs(dx) > 2:
            mx = max(-1.0, min(1.0, dx / 24.0))
        if abs(dy) > 2:
            my = max(-1.0, min(1.0, dy / 24.0))
        self._move = (mx, my)

    # ---- 菜单/商店/设置点按命中 (与键盘选择共用同一套代码) ----
    def touch_hit(self, pos):
        g = self.game
        st = g.state
        x, y = pos
        if st == g.STATE_MENU:
            for i in range(4):
                if g.menu_rect(i).collidepoint(pos):
                    g.menu_sel = i
                    self._set('confirm')
                    return True
        elif st == g.STATE_MODESEL:
            for i in range(len(g._mode_entries())):
                if g.mode_rect(i).collidepoint(pos):
                    g.modesel_sel = i
                    self._set('confirm')
                    return True
        elif st == g.STATE_DIFFSEL:
            for i in range(3):
                if g.diff_rect(i).collidepoint(pos):
                    g.diffsel_sel = i
                    self._set('confirm')
                    return True
        elif st == g.STATE_PAUSED:
            for i in range(5):
                if g.pause_rect(i).collidepoint(pos):
                    g.pause_sel = i
                    self._set('confirm')
                    return True
        elif st == g.STATE_SHOP:
            for i in range(len(g.shop.ITEMS)):
                if g.shop_rect(i).collidepoint(pos):
                    g.shop.selected = i
                    self._set('confirm')
                    return True
        elif st == g.STATE_SETTINGS:
            for i in range(5):
                if g.settings_rect(i).collidepoint(pos):
                    g.settings_sel = i
                    # 音量行: 点音量条直接设值; 其余行=confirm(切换/返回)
                    if i < 3 and g.settings_bar_rect(i).collidepoint(pos):
                        seg = int((x - (g.settings_bar_rect(i).x)) // 12)
                        g._set_volume(i, max(1, min(10, seg + 1)))
                    else:
                        self._set('confirm')
                    return True
        elif st in (g.STATE_HELP, g.STATE_INTER):
            self._set('confirm')
            return True
        elif st in (g.STATE_GAMEOVER, g.STATE_VICTORY):
            # 下半屏=重玩, 上半屏=回主菜单
            if y > LOGICAL_H * 0.5:
                self._set('confirm')
            else:
                self._set('back')
            return True
        return False

    # ---- 屏上按钮绘制 (半透明圆) ----
    def draw_touch_ui(self, surface):
        surf = pygame.display.get_surface()
        if surf is None:
            return
        sw, sh = surf.get_size()
        scale = min(sw / LOGICAL_W, sh / LOGICAL_H)
        ox = (sw - LOGICAL_W * scale) / 2.0
        oy = (sh - LOGICAL_H * scale) / 2.0

        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)

        def circle(cx, cy, r, color):
            sx = ox + cx * scale
            sy = oy + cy * scale
            sr = r * scale
            pygame.draw.circle(overlay, color, (int(sx), int(sy)), int(sr))
            pygame.draw.circle(overlay, (255, 255, 255, 120),
                               (int(sx), int(sy)), int(sr), 2)

        bx, by, br = self._btn_bomb()
        circle(bx, by, br, (255, 80, 80, 110))
        bx, by, br = self._btn_cycle()
        circle(bx, by, br, (80, 160, 255, 110))
        bx, by, br = self._btn_pause()
        circle(bx, by, br, (200, 200, 200, 110))

        surface.blit(overlay, (0, 0))
