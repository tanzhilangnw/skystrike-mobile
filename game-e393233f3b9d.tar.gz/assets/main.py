#!/usr/bin/env python3
"""
Sky Strike v3 - 雷霆战机
竖版射击 · 战役/无尽/双人 · 菜单/设置/存档 · 中文 UI
操作: WASD/方向键移动 | 自动射击 | Q切换武器 | 空格炸弹 | P暂停 | M静音
"""
import asyncio
import pygame
import random
import math
import sys
import os
import json
import importlib

# pygame-ce provides grayscale in the browser; older desktop pygame uses this fallback.
_np = None
if sys.platform != "emscripten" and not hasattr(pygame.transform, "grayscale"):
    _np = importlib.import_module("numpy")

# M6: 统一输入层 (keyboard / touch)
from input_provider import (InputProvider, KeyboardInput, TouchInput,
                            detect_platform, LOGICAL_W, LOGICAL_H,
                            TOUCH_OFFSET_Y)

# ===== 常量 =====
SCREEN_W, SCREEN_H = 480, 800
FPS = 60
DARK_BG = (5, 5, 15)

# 颜色
WHITE = (255, 255, 255)
CYAN = (0, 240, 255)
BLUE = (40, 100, 255)
RED = (255, 50, 50)
ORANGE = (255, 150, 0)
YELLOW = (255, 230, 50)
PURPLE = (170, 50, 255)
GREEN = (50, 255, 130)
PINK = (255, 80, 180)
DARK_RED = (120, 20, 20)
GRAY = (100, 100, 110)

# M8 方向C 墨水/纸色板 (HUD 与菜单统一语言)
INK = (229, 241, 249)
INK_SOFT = (163, 190, 209)
CREAM = (250, 244, 232)
INK_ROSE = (255, 124, 112)
INK_INDIGO = (111, 220, 244)
INK_GOLD = (250, 204, 126)
INK_LEAF = (120, 230, 167)

# 武器类型
WPN_VULCAN = 0
WPN_LASER = 1
WPN_MISSILE = 2
WPN_NAMES = ['VULCAN', 'LASER', 'MISSILE']
WPN_COLORS = [CYAN, GREEN, PURPLE]

# 难度系数 (敌人预算 / 弹幕密度 / Boss HP / 初始命)
DIFF_TABLE = {'easy': (0.7, 0.7, 0.8, 4),
              'normal': (1.0, 1.0, 1.0, 3),
              'hell': (1.4, 1.3, 1.3, 2)}
DIFF = {'budget': 1.0, 'fire': 1.0, 'bosshp': 1.0, 'lives': 3}


def apply_difficulty(key):
    b, f, h, lv = DIFF_TABLE.get(key, DIFF_TABLE['normal'])
    DIFF.update({'budget': b, 'fire': f, 'bosshp': h, 'lives': lv})

# 战役模式开关与章末 Boss modifier (仅战役生效; 无尽保持现状)
CAMPAIGN = {'active': False}
BOSS_MOD_TABLE = {
    1: dict(hp=1.0, spd=1.0, density=1.0, summon=8.0, tint=None),
    2: dict(hp=1.4, spd=1.15, density=1.0, summon=8.0, tint=(255, 140, 60)),
    3: dict(hp=1.8, spd=1.0, density=1.0, summon=4.0, tint=None),
    4: dict(hp=2.4, spd=1.0, density=1.3, summon=6.0, tint=(190, 80, 255)),
}


def boss_mod(chapter):
    return BOSS_MOD_TABLE.get(chapter, BOSS_MOD_TABLE[1])

# ===== 素材 (Kenney Space Shooter Redux, CC0) =====
ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
ASSETS = {}


class Assets:
    """加载并缩放 Kenney CC0 素材; 缺失时游戏回退到程序化绘制"""

    @staticmethod
    def available():
        return os.path.isdir(ASSET_DIR)

    @staticmethod
    def _load(rel, scale=1.0):
        s = pygame.image.load(os.path.join(ASSET_DIR, rel)).convert_alpha()
        if scale != 1.0:
            s = pygame.transform.smoothscale(
                s, (max(1, int(s.get_width() * scale)),
                    max(1, int(s.get_height() * scale))))
        return s

    @staticmethod
    def tint(surf, color):
        """按不透明轮廓重着色, 保留 alpha"""
        m = pygame.mask.from_surface(surf, threshold=10)
        out = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        m.to_surface(surface=out, setcolor=(*color, 255), unsetcolor=(0, 0, 0, 0))
        return out

    @staticmethod
    def shade(surf, color):
        """乘色重着色, 保留明暗层次与 alpha"""
        out = surf.copy()
        out.fill((*color, 255), special_flags=pygame.BLEND_RGB_MULT)
        return out

    @staticmethod
    def watercolor(surf, desat=0.55, warm=(255, 238, 214)):
        """M8 方向C: 部分去饱和 + 暖调乘色, 让素材融入水彩天空色板"""
        out = surf.copy()
        grayscale = getattr(pygame.transform, 'grayscale', None)
        if grayscale is not None:
            gray = grayscale(out)
        else:
            # pygame < 2.2 has no transform.grayscale; use surfarray for compatibility.
            rgb = pygame.surfarray.array3d(out).astype(_np.uint16)
            channel = ((rgb[:, :, 0] * 299 + rgb[:, :, 1] * 587 +
                        rgb[:, :, 2] * 114 + 500) // 1000).astype(_np.uint8)
            rgba = _np.empty((*channel.shape, 4), dtype=_np.uint8)
            rgba[:, :, :3] = channel[:, :, None]
            rgba[:, :, 3] = pygame.surfarray.array_alpha(out)
            gray = pygame.image.frombuffer(rgba.tobytes(), out.get_size(), 'RGBA').copy()
        gray.set_alpha(int(255 * desat))
        out.blit(gray, (0, 0))
        out.fill((*warm, 255), special_flags=pygame.BLEND_RGB_MULT)
        return out

    @staticmethod
    def rh(s, h):
        """等比缩放到指定高度"""
        w, hh = s.get_size()
        return pygame.transform.smoothscale(s, (max(1, int(w * h / hh)), h))

    @staticmethod
    def slice_atlas(rel, cols, rows, cell, target, step=1):
        """把图集切成 cols×rows 网格的 cell 帧, 跳过全透明帧, 缩放到 target px"""
        path = os.path.join(ASSET_DIR, rel)
        if not os.path.exists(path):
            return []
        atlas = pygame.image.load(path).convert_alpha()
        frames = []
        for i in range(cols * rows):
            if i % step:
                continue
            cx = (i % cols) * cell
            cy = (i // cols) * cell
            f = atlas.subsurface((cx, cy, cell, cell)).copy()
            if f.get_alpha() is None:
                continue
            # 跳过完全空白帧(第 0 帧)
            if not pygame.mask.from_surface(f, threshold=10).count():
                continue
            frames.append(pygame.transform.smoothscale(f, (target, target)))
        return frames

    @staticmethod
    def _try(rel, scale=1.0):
        """可选素材: 缺失返回 None 而非抛异常, 供 HUD 增量素材使用"""
        if not os.path.exists(os.path.join(ASSET_DIR, rel)):
            return None
        return Assets._load(rel, scale)

    @staticmethod
    def build():
        a = {}
        wc = Assets.watercolor
        # 玩家与敌机: 深色墨水剪影 (玩家靛蓝 / 敌机玫瑰棕), Boss 保留红色焦点
        INK_P1 = (92, 108, 140)
        INK_P2 = (122, 96, 142)
        INK_EN = (150, 92, 84)
        wcP = Assets._try('ships/wc_player.png')
        wcE = Assets._try('ships/wc_enemy.png')
        if wcP and wcE:
            # M8b: 概念图同款手绘机; 敌机同 silhouette 靠水彩色调区分型号
            p1 = Assets.rh(wcP, 60)
            a['player'] = p1
            a['player_damage'] = wc(p1, 0.45, (128, 92, 74))
            p2 = wc(Assets.rh(wcP, 60), 0.5, INK_P2)
            a['player2'] = p2
            a['player2_damage'] = wc(p2, 0.45, (128, 92, 74))
            e = Assets.rh(wcE, 46)
            a['scout'] = e
            a['fighter'] = wc(e, 0.45, (96, 110, 142))
            a['kamikaze'] = wc(e, 0.45, (186, 138, 66))
            a['shielded'] = wc(e, 0.45, (110, 122, 150))
            a['splitter'] = wc(e, 0.45, (150, 92, 84))
            a['bomber'] = wc(Assets.rh(wcE, 66), 0.5, (96, 84, 80))
        else:
            a['player'] = wc(Assets._load('playerShip1_blue.png', 0.62), 0.5, INK_P1)
            a['player_damage'] = wc(Assets._load('Damage/playerShip1_damage1.png', 0.62), 0.5, INK_P1)
            a['player2'] = wc(Assets._try('playerShip2_orange.png', 0.62)
                              or Assets._load('playerShip1_blue.png', 0.62), 0.5, INK_P2)
            _p2d = Assets._try('Damage/playerShip2_damage1.png', 0.62)
            a['player2_damage'] = wc(_p2d, 0.5, INK_P2) if _p2d else None
            a['scout'] = wc(Assets._load('Enemies/enemyRed1.png', 0.42), 0.5, INK_EN)
            a['fighter'] = wc(Assets._load('Enemies/enemyBlue2.png', 0.50), 0.5, INK_EN)
            a['bomber'] = wc(Assets._load('Enemies/enemyBlack4.png', 0.60), 0.5, (96, 84, 80))
            a['kamikaze'] = wc(Assets._load('Enemies/enemyGreen1.png', 0.45), 0.5, INK_EN)
            a['shielded'] = wc(Assets._load('Enemies/enemyBlue5.png', 0.50), 0.5, INK_EN)
            a['splitter'] = wc(Assets._load('Enemies/enemyGreen5.png', 0.50), 0.5, INK_EN)
        a['boss'] = Assets.rh(wcE, 150) if wcE else Assets._load('Enemies/enemyBlack1.png', 1.8)
        # 子弹
        a['bullet_vulcan'] = Assets._load('Lasers/laserBlue06.png', 0.6)
        a['bullet_laser'] = Assets._load('Lasers/laserGreen09.png', 0.8)
        missile_base = Assets._load('Lasers/laserRed06.png', 1.2)
        a['bullet_missile'] = Assets.tint(missile_base, PURPLE)
        eb_base = Assets._load('Lasers/laserRed06.png', 0.6)
        for c in (RED, ORANGE, YELLOW, PINK, PURPLE):
            a[('ebullet', c)] = Assets.tint(eb_base, c)
        a[('ebullet', GREEN)] = Assets._load('Lasers/laserGreen06.png', 0.6)
        # 道具
        a['pu_spread'] = Assets._load('Power-ups/powerupYellow_star.png', 0.85)
        a['pu_missile_ammo'] = Assets._load('Power-ups/powerupRed_bolt.png', 0.85)
        a['pu_bomb'] = Assets._load('Power-ups/powerupRed_star.png', 0.85)
        a['pu_heal'] = Assets._load('Power-ups/pill_green.png', 0.85)
        a['pu_shield'] = Assets._load('Power-ups/powerupBlue_shield.png', 0.85)
        a['pu_energy'] = Assets._load('Power-ups/powerupGreen_bolt.png', 0.85)
        # 护盾 / 星星 / 引擎火焰
        a['shield'] = Assets.tint(Assets._load('Effects/shield3.png', 0.55), CYAN)
        a['shield_enemy'] = Assets.tint(Assets._load('Effects/shield3.png', 0.5), BLUE)
        a['star1'] = Assets._load('Effects/star1.png', 0.5)
        a['star2'] = Assets._load('Effects/star2.png', 0.5)
        a['star3'] = Assets._load('Effects/star3.png', 0.5)
        a['flame'] = [Assets._load('Effects/fire%02d.png' % i, 0.8)
                      for i in range(0, 20, 2)]
        # 陨石: 概念图同款手绘浮空岩; 缺图回退 Kenney
        wcR = Assets._try('ships/wc_rock.png')
        if wcR:
            a['meteor_big'] = Assets.rh(wcR, 68)
            a['meteor_med'] = Assets.rh(wcR, 40)
            a['meteor_small'] = Assets.rh(wcR, 24)
        else:
            a['meteor_big'] = wc(Assets._load('Meteors/meteorBrown_big1.png', 0.7), 0.4, (140, 110, 92))
            a['meteor_med'] = wc(Assets._load('Meteors/meteorBrown_med1.png', 0.9), 0.4, (140, 110, 92))
            a['meteor_small'] = wc(Assets._load('Meteors/meteorBrown_small1.png', 1.0), 0.4, (140, 110, 92))
        # 序列帧爆炸(CC0 2D Explosion Animations #2, 2048² 8×8 网格 256px)
        a['boom1'] = Assets.slice_atlas('fx/boom1.png', 8, 4, 128, 128, step=1)
        a['boom2'] = Assets.slice_atlas('fx/boom2.png', 8, 4, 128, 128, step=1)
        # HUD 生命图标(Kenney UI, 可选) — 墨水化
        _l1 = Assets._try('UI/playerLife1_blue.png', 0.5)
        _l2 = Assets._try('UI/playerLife1_orange.png', 0.5)
        a['life_p1'] = wc(_l1, 0.5, INK_P1) if _l1 else None
        a['life_p2'] = wc(_l2, 0.5, INK_P2) if _l2 else None
        # 加算辉光
        a['glow'] = Assets._make_glow()
        return a

    @staticmethod
    def _make_glow(radius=12, color=(120, 200, 255)):
        # 加算混合不吃 alpha, 衰减必须做进 RGB
        s = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        s.fill((0, 0, 0, 0))
        for r in range(radius, 0, -1):
            f = (1 - r / radius) ** 2
            pygame.draw.circle(s, (int(color[0] * f), int(color[1] * f),
                                   int(color[2] * f), 255), (radius, radius), r)
        return s


class Audio:
    """CC0 音效 + BGM; 无 mixer 或无素材时静默禁用"""
    enabled = True
    muted = False
    sounds = {}
    _volumes = {'retro_laser_01': 0.25, 'rocket_01': 0.5, 'explosion_01': 0.7,
                'explosion_02': 0.5, 'retro_explosion': 0.8, 'retro_beep_04': 0.5,
                'beep_01': 0.4, 'misc_03': 0.5}

    @staticmethod
    def init():
        try:
            pygame.mixer.init()
        except Exception:
            Audio.enabled = False
            return
        d = os.path.join(ASSET_DIR, 'audio')
        if not os.path.isdir(d):
            Audio.enabled = False
            return
        for name, vol in Audio._volumes.items():
            p = os.path.join(d, name + '.ogg')
            if os.path.exists(p):
                try:
                    s = pygame.mixer.Sound(p)
                    s.set_volume(vol)
                    Audio.sounds[name] = s
                except Exception:
                    pass
        # 低 HP 心跳: misc_03 降速重采样(一次性, 纯 python)
        if 'misc_03' in Audio.sounds:
            try:
                Audio._volumes['heartbeat'] = 0.6
                Audio.sounds['heartbeat'] = Audio._slow(Audio.sounds['misc_03'], 0.55)
            except Exception:
                pass
        if not Audio.sounds:
            Audio.enabled = False

    @staticmethod
    def _slow(sound, factor):
        """按帧重采样降低播放速率, 得到低沉心跳感"""
        import array
        freq, fmt, chans = pygame.mixer.get_init()
        if abs(fmt) != 16 or chans < 1:
            return sound
        src = array.array('h', sound.get_raw())
        frames = len(src) // chans
        out_frames = int(frames / factor)
        out = array.array('h', bytes(2 * out_frames * chans))
        for i in range(out_frames):
            s0 = int(i * factor) * chans
            for c in range(chans):
                out[i * chans + c] = src[s0 + c]
        return pygame.mixer.Sound(out)

    @staticmethod
    def play(name):
        if not Audio.enabled or Audio.muted:
            return
        s = Audio.sounds.get(name)
        if s:
            s.play()

    @staticmethod
    def music():
        if not Audio.enabled:
            return
        p = os.path.join(ASSET_DIR, 'audio', 'music.ogg')
        if os.path.exists(p):
            try:
                pygame.mixer.music.load(p)
                pygame.mixer.music.set_volume(Audio.music_volume())
                pygame.mixer.music.play(-1)
            except Exception:
                pass

    @staticmethod
    def music_volume():
        m = Config.get('vol_master') / 10.0
        mu = Config.get('vol_music') / 10.0
        return 0.5 * m * mu

    @staticmethod
    def apply_volumes():
        """设置页改动后实时生效"""
        if not Audio.enabled:
            return
        m = Config.get('vol_master') / 10.0
        sf = Config.get('vol_sfx') / 10.0
        for name, s in Audio.sounds.items():
            s.set_volume(Audio._volumes.get(name, 0.5) * m * sf)
        try:
            pygame.mixer.music.set_volume(Audio.music_volume())
        except Exception:
            pass

    @staticmethod
    def toggle():
        Audio.muted = not Audio.muted
        if not Audio.enabled:
            return
        if Audio.muted:
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()


# ===== 设置与存档持久化 (~/.sky-strike/) =====
SAVE_DIR = os.path.join(os.path.expanduser('~'), '.sky-strike')
CONFIG_PATH = os.path.join(SAVE_DIR, 'config.json')
SAVE_PATH = os.path.join(SAVE_DIR, 'save.json')


class Config:
    """设置持久化; 读写出错静默降级, 不 crash"""
    DEFAULTS = {'vol_master': 8, 'vol_music': 7, 'vol_sfx': 8, 'shake': True,
                'tutorial_seen': False, 'toasts': {}}
    data = dict(DEFAULTS)

    @staticmethod
    def load():
        Config.data = dict(Config.DEFAULTS)
        try:
            with open(CONFIG_PATH) as f:
                Config.data.update(json.load(f))
        except Exception:
            pass

    @staticmethod
    def save():
        try:
            os.makedirs(SAVE_DIR, exist_ok=True)
            with open(CONFIG_PATH, 'w') as f:
                json.dump(Config.data, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    @staticmethod
    def get(key):
        return Config.data.get(key, Config.DEFAULTS.get(key))

    @staticmethod
    def set(key, value):
        Config.data[key] = value
        Config.save()


class SaveData:
    """各模式最高分 / 通关标记"""
    DEFAULTS = {'endless': {'high': 0},
                'campaign': {'high': 0, 'cleared': False, 'best_wave': 0},
                'coop': {'high': 0}}
    data = None

    @staticmethod
    def load():
        SaveData.data = json.loads(json.dumps(SaveData.DEFAULTS))
        try:
            with open(SAVE_PATH) as f:
                loaded = json.load(f)
            for k, v in loaded.items():
                if k in SaveData.data and isinstance(v, dict):
                    SaveData.data[k].update(v)
        except Exception:
            pass

    @staticmethod
    def save():
        try:
            os.makedirs(SAVE_DIR, exist_ok=True)
            with open(SAVE_PATH, 'w') as f:
                json.dump(SaveData.data, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    @staticmethod
    def record(mode, score, wave=0, cleared=False):
        d = SaveData.data.setdefault(mode, dict(SaveData.DEFAULTS.get(mode, {})))
        d['high'] = max(d.get('high', 0), score)
        if mode == 'campaign':
            d['best_wave'] = max(d.get('best_wave', 0), wave)
            d['cleared'] = d.get('cleared', False) or cleared
        SaveData.save()


# ===== 字体 (OFL: Noto Sans SC 正文 / ZCOOL 庆科黄油体 标题) =====
_FONT_CACHE = {}


class Fonts:
    body_path = None
    title_path = None

    @staticmethod
    def init():
        d = os.path.join(ASSET_DIR, 'font')
        bp = os.path.join(d, 'NotoSansSC.ttf')
        tp = os.path.join(d, 'ZCOOLQingKeHuangYou.ttf')
        Fonts.body_path = bp if os.path.exists(bp) else None
        Fonts.title_path = tp if os.path.exists(tp) else None

    @staticmethod
    def cjk():
        return Fonts.body_path is not None

    @staticmethod
    def get(size, bold=False, title=False):
        path = Fonts.title_path if (title and Fonts.title_path) else Fonts.body_path
        key = (path, size, bold)
        f = _FONT_CACHE.get(key)
        if f is None:
            f = pygame.font.Font(path, size) if path else pygame.font.Font(None, size)
            if bold:
                f.set_bold(True)
            _FONT_CACHE[key] = f
        return f


# ===== UI 字符串表 (中文为主, 字体缺失回退英文) =====
TEXT = {
    'menu_sub':    ('雷 霆 战 机  v3', 'SKY STRIKE v3'),
    'menu_press':  ('按 回车 / 空格 开始', 'PRESS ENTER'),
    'menu_i1':     ('WASD / 方向键 移动 · 自动开火', 'WASD/Arrows Move · Auto Fire'),
    'menu_i2':     ('Q 切换武器 · 1/2/3 直选', 'Q Switch Weapon · 1/2/3 Direct'),
    'menu_i3':     ('空格 炸弹 · P 暂停 · M 静音', 'SPACE Bomb · P Pause · M Mute'),
    'menu_i4':     ('贴近敌弹擦弹可得分!', 'Graze bullets for bonus score!'),
    'menu_high':   ('最高分: %s', 'HIGH SCORE: %s'),
    'wpn0':        ('火神炮', 'VULCAN'),
    'wpn1':        ('激光', 'LASER'),
    'wpn2':        ('导弹', 'MISSILE'),
    'hud_weapon':  ('[Q] %s', '[Q] %s'),
    'hud_combo':   ('COMBO x%d', 'COMBO x%d'),
    'hud_graze':   ('擦弹 %d', 'GRAZE %d'),
    'hud_wave':    ('W%d', 'W%d'),
    'stage_campaign': ('第 %d 章 · 第 %d/5 波', 'CH %d · WAVE %d/5'),
    'stage_endless':  ('第 %d 波', 'WAVE %d'),
    'stage_boss':     ('BOSS 战', 'BOSS BATTLE'),
    'hud_pause_hint': ('P 暂停', 'P PAUSE'),
    'hint_pc':     ('WASD/方向键 移动 · 自动开火 · Q 切武器 · 空格 炸弹',
                    'WASD/ARROWS move · auto-fire · Q weapon · SPACE bomb'),
    'hint_android': ('拖动移动 · 自动开火 · 按钮放炸弹/切武器',
                     'drag to move · auto-fire · buttons for bomb/weapon'),
    'hint_coop':   ('P1 WASD+Q+空格 · P2 方向键+右Ctrl切武器+右Shift炸弹',
                    'P1 WASD+Q+SPACE · P2 ARROWS+RCTRL+RSHIFT'),
    'toast_graze': ('擦弹 +10!贴近敌弹风险与收益并存',
                    'GRAZE +10! skimming bullets pays'),
    'toast_shop':  ('用积分强化战机,Esc 跳过',
                    'spend score to upgrade · Esc skips'),
    'toast_shield': ('护盾可挡一次伤害', 'shield blocks one hit'),
    'toast_combo': ('连杀倍率生效中', 'combo multiplier active'),
    'inter_title': ('第 %d 章 完成', 'CHAPTER %d CLEAR'),
    'inter_score': ('本章得分 %s', 'chapter score %s'),
    'inter_hp':    ('剩余 HP %d/%d', 'HP left %d/%d'),
    'inter_time':  ('用时 %d:%02d', 'time %d:%02d'),
    'inter_hint':  ('回车 继续', 'ENTER to continue'),
    'inter_hint_touch': ('点按屏幕 继续', 'Tap to continue'),
    'victory_title': ('胜利!', 'VICTORY!'),
    'victory_sub':   ('战役通关', 'CAMPAIGN CLEARED'),
    'st_score': ('总分 %s', 'score %s'),
    'st_time':  ('用时 %d:%02d', 'time %d:%02d'),
    'st_combo': ('最高连杀 %d', 'max combo %d'),
    'st_graze': ('擦弹 %d', 'graze %d'),
    'st_lives': ('剩余命 %d', 'lives left %d'),
    'again_hint': ('R 重玩 · Esc 回主菜单', 'R replay · Esc menu'),
    'again_hint_touch': ('点下方重玩 · 点上方回主菜单', 'Tap below replay · tap above menu'),
    'go_reach': ('到达第 %d 章 · 第 %d 波', 'reached CH %d wave %d'),
    'boss_phase':  ('阶段 %d/3', 'PHASE %d/3'),
    'banner_wave': ('第 %d 波', 'WAVE %d'),
    'banner_boss': ('⚠ BOSS 战 · 第 %d 波 ⚠', '⚠ BOSS WAVE %d ⚠'),
    'pause_title': ('已暂停', 'PAUSED'),
    'pause_sub':   ('P 继续', 'P to resume'),
    'go_title':    ('游戏结束', 'GAME OVER'),
    'go_score':    ('得分: %s', 'SCORE: %s'),
    'go_wave':     ('波次: %d', 'WAVE: %d'),
    'go_graze':    ('擦弹: %d', 'GRAZE: %d'),
    'go_new':      ('★ 新纪录 ★', '★ NEW RECORD ★'),
    'go_restart':  ('R 重开 | Esc 主菜单', 'R Restart | ESC Menu'),
    'go_restart_touch': ('点下方重开 · 点上方回主菜单', 'Tap below restart · tap above menu'),
    'shop_title':  ('— 波间商店 —', '— SHOP —'),
    'shop_score':  ('积分: %s', 'Score: %s'),
    'shop_hint':   ('↑↓ 选择 | 回车 购买 | Esc 跳过', '↑↓ Select | ENTER Buy | ESC Skip'),
    'shop_hint_touch': ('点按条目 购买 · 点跳过 继续', 'Tap to buy · tap Skip'),
    'it_hp':       ('HP 上限 +2', 'Max HP +2'),
    'it_hp_d':     ('回复至满血', 'Refill to full'),
    'it_dmg':      ('伤害强化', 'Damage Up'),
    'it_dmg_d':    ('子弹伤害 ×1.3', 'Bullet damage x1.3'),
    'it_spd':      ('引擎加速', 'Speed Up'),
    'it_spd_d':    ('移动速度提升', 'Move speed up'),
    'it_bomb':     ('炸弹 +1', 'Bomb +1'),
    'it_bomb_d':   ('额外一枚炸弹', 'Extra bomb'),
    'it_mis':      ('导弹 +4', 'Missile +4'),
    'it_mis_d':    ('补充导弹弹药', 'Refill missiles'),
    'it_skip':     ('跳过', 'Skip'),
    'it_skip_d':   ('进入下一波', 'Next wave'),
    'set_title':   ('设 置', 'SETTINGS'),
    'set_sub':     ('↑↓ 选择 · ←→ 调节 · Esc 返回', '↑↓ Select · ←→ Adjust · Esc Back'),
    'set_sub_touch': ('点按条目 · 点音量条 调节', 'Tap row · tap bar to adjust'),
    'set_master':  ('主音量', 'Master Volume'),
    'set_music':   ('音乐音量', 'Music Volume'),
    'set_sfx':     ('音效音量', 'SFX Volume'),
    'set_shake':   ('屏幕震动', 'Screen Shake'),
    'set_on':      ('开', 'On'),
    'set_off':     ('关', 'Off'),
    'set_back':    ('返回', 'Back'),
    'mute_on':     ('已静音 (M 恢复)', 'Muted (M to unmute)'),
    'menu_start':    ('开始游戏', 'Start Game'),
    'menu_help':     ('操作说明', 'How to Play'),
    'menu_settings': ('设置', 'Settings'),
    'menu_quit':     ('退出', 'Quit'),
    'mode_title':    ('选 择 模 式', 'SELECT MODE'),
    'mode_campaign': ('单人 · 战役', 'Campaign'),
    'mode_campaign_d': ('4 章 × 5 波 · 通关结算', '4 chapters · victory ending'),
    'mode_endless':  ('单人 · 无尽', 'Endless'),
    'mode_endless_d': ('无限波次 · 挑战高分', 'Infinite waves · high score'),
    'mode_coop':     ('双人 · 合作', 'Co-op (2P)'),
    'mode_coop_d':   ('本地同屏双人 · 仅 PC', 'Local same-screen 2P · PC only'),
    'diff_title':    ('选 择 难 度', 'SELECT DIFFICULTY'),
    'diff_easy':     ('简单', 'Easy'),
    'diff_easy_d':   ('敌人与弹幕减少 · 4 命', 'Fewer enemies · 4 lives'),
    'diff_normal':   ('标准', 'Normal'),
    'diff_normal_d': ('标准体验 · 3 命', 'Standard · 3 lives'),
    'diff_hell':     ('地狱', 'Hell'),
    'diff_hell_d':   ('弹幕地狱 · 2 命', 'Bullet hell · 2 lives'),
    'pause_resume':  ('继续游戏', 'Resume'),
    'pause_restart': ('重新开始', 'Restart'),
    'pause_help':    ('操作说明', 'How to Play'),
    'pause_settings': ('设置', 'Settings'),
    'pause_quit':    ('回主菜单', 'Quit to Menu'),
    'sel_hint':      ('↑↓ 选择 · 回车 确认 · Esc 返回', '↑↓ Select · Enter Confirm · Esc Back'),
    'sel_hint_touch': ('点按条目 选择', 'Tap an entry to select'),
    'help_title':    ('操 作 说 明', 'HOW TO PLAY'),
    'help_move':     ('移动:WASD / 方向键 · 自动开火', 'Move: WASD/Arrows · auto fire'),
    'help_move_touch': ('移动:全屏拖拽 · 自动开火', 'Drag anywhere · auto fire'),
    'help_wpn':      ('武器:Q 循环切换 · 1/2/3 直选', 'Weapon: Q cycle · 1/2/3 direct'),
    'help_wpn_touch': ('武器:点右下小圆 循环切换', 'Weapon: tap small circle'),
    'help_wpn2':     ('火神炮无限 · 激光耗能量 · 导弹耗弹药', 'Vulcan free · Laser energy · Missile ammo'),
    'help_bomb':     ('空格:炸弹清屏 (数量有限)', 'SPACE: bomb clears bullets'),
    'help_bomb_touch': ('炸弹:点右下大圆 清屏 (数量有限)', 'Bomb: tap big circle'),
    'help_pause':    ('P / Esc 暂停 · M 静音', 'P/Esc pause · M mute'),
    'help_pause_touch': ('暂停:点右上小圆', 'Pause: tap top-right circle'),
    'help_graze':    ('擦弹:敌弹贴脸掠过 +10 分', 'Graze: +10 per near miss'),
    'help_combo':    ('连杀:combo 得分倍率最高 ×10', 'Kill streak: up to x10 score'),
    'help_shop':     ('商店:每波清完用积分强化战机', 'Shop: spend score between waves'),
    'help_coop':     ('双人:P1 WASD · P2 方向键 + 右Shift 炸弹', 'Co-op: P1 WASD · P2 arrows + RShift'),
    'help_back':     ('Esc / 回车 返回', 'Esc / Enter to go back'),
    'help_back_touch': ('点按 返回', 'Tap to go back'),
}


def T(key, *args):
    zh, en = TEXT.get(key, (key, key))
    s = zh if Fonts.cjk() else en
    if args:
        s = s % args
    return s


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def lerp(a, b, t):
    return a + (b - a) * t


def rand_range(lo, hi):
    return random.uniform(lo, hi)


# ===== 预渲染精灵工厂 =====
class SpriteFactory:
    """启动时预渲染所有飞船精灵到 Surface，运行时直接 blit"""

    @staticmethod
    def make_player_ship(size=28):
        """玩家飞船 - 流线型蓝白战斗机"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        # 主体
        body_pts = [
            (cx, cy - size * 0.9),
            (cx - size * 0.2, cy - size * 0.4),
            (cx - size * 0.7, cy + size * 0.2),
            (cx - size * 0.8, cy + size * 0.6),
            (cx - size * 0.3, cy + size * 0.4),
            (cx, cy + size * 0.6),
            (cx + size * 0.3, cy + size * 0.4),
            (cx + size * 0.8, cy + size * 0.6),
            (cx + size * 0.7, cy + size * 0.2),
            (cx + size * 0.2, cy - size * 0.4),
        ]
        pygame.draw.polygon(s, (20, 60, 120), body_pts)
        pygame.draw.polygon(s, (60, 140, 220), body_pts, 2)
        # 座舱
        cockpit_pts = [
            (cx, cy - size * 0.6),
            (cx - size * 0.12, cy - size * 0.1),
            (cx, cy + size * 0.05),
            (cx + size * 0.12, cy - size * 0.1),
        ]
        pygame.draw.polygon(s, (100, 200, 255), cockpit_pts)
        pygame.draw.polygon(s, (180, 240, 255), cockpit_pts, 1)
        # 引擎口
        pygame.draw.rect(s, (40, 40, 60),
                        (cx - size * 0.25, cy + size * 0.45, size * 0.15, size * 0.15))
        pygame.draw.rect(s, (40, 40, 60),
                        (cx + size * 0.1, cy + size * 0.45, size * 0.15, size * 0.15))
        # 翼尖灯
        pygame.draw.circle(s, RED, (int(cx - size * 0.75), int(cy + size * 0.3)), 2)
        pygame.draw.circle(s, GREEN, (int(cx + size * 0.75), int(cy + size * 0.3)), 2)
        return s

    @staticmethod
    def make_enemy_scout(size=18):
        """侦察机 - 红色小型三角"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        pts = [(cx, cy + size * 0.8), (cx - size * 0.6, cy - size * 0.5),
               (cx - size * 0.15, cy - size * 0.2), (cx + size * 0.15, cy - size * 0.2),
               (cx + size * 0.6, cy - size * 0.5)]
        pygame.draw.polygon(s, (140, 30, 30), pts)
        pygame.draw.polygon(s, (255, 80, 60), pts, 2)
        pygame.draw.circle(s, YELLOW, (cx, cy + size * 0.3), 3)
        return s

    @staticmethod
    def make_enemy_fighter(size=24):
        """战斗机 - 橙色中型"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        pts = [(cx, cy + size * 0.8), (cx - size * 0.9, cy - size * 0.2),
               (cx - size * 0.5, cy - size * 0.6), (cx - size * 0.15, cy - size * 0.3),
               (cx + size * 0.15, cy - size * 0.3), (cx + size * 0.5, cy - size * 0.6),
               (cx + size * 0.9, cy - size * 0.2)]
        pygame.draw.polygon(s, (120, 60, 10), pts)
        pygame.draw.polygon(s, (255, 160, 40), pts, 2)
        pygame.draw.circle(s, RED, (cx, cy + size * 0.2), 4)
        pygame.draw.circle(s, (255, 100, 50), (cx, cy + size * 0.2), 2)
        return s

    @staticmethod
    def make_enemy_bomber(size=32):
        """轰炸机 - 紫色重型"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        pygame.draw.circle(s, (80, 20, 120), (cx, cy), int(size * 0.75))
        pygame.draw.circle(s, (160, 60, 220), (cx, cy), int(size * 0.75), 2)
        pygame.draw.circle(s, (60, 15, 90), (cx, cy), int(size * 0.45))
        # 炮口
        for angle in [math.pi * 0.3, math.pi * 0.5, math.pi * 0.7]:
            ex = int(cx + math.cos(angle) * size * 0.7)
            ey = int(cy + math.sin(angle) * size * 0.7)
            pygame.draw.circle(s, (200, 100, 255), (ex, ey), 4)
        pygame.draw.circle(s, PURPLE, (cx, cy), 5)
        return s

    @staticmethod
    def make_enemy_kamikaze(size=16):
        """自爆机 - 粉红色闪烁"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        pts = [(cx, cy + size * 0.9), (cx - size * 0.5, cy),
               (cx - size * 0.3, cy - size * 0.6), (cx + size * 0.3, cy - size * 0.6),
               (cx + size * 0.5, cy)]
        pygame.draw.polygon(s, (150, 30, 80), pts)
        pygame.draw.polygon(s, PINK, pts, 2)
        pygame.draw.circle(s, YELLOW, (cx, cy), 4)
        return s

    @staticmethod
    def make_enemy_shield(size=26):
        """护盾机 - 带护盾的蓝色中型"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        pts = [(cx, cy + size * 0.7), (cx - size * 0.7, cy),
               (cx - size * 0.4, cy - size * 0.6), (cx + size * 0.4, cy - size * 0.6),
               (cx + size * 0.7, cy)]
        pygame.draw.polygon(s, (20, 50, 100), pts)
        pygame.draw.polygon(s, (80, 160, 255), pts, 2)
        pygame.draw.circle(s, CYAN, (cx, cy), 4)
        return s

    @staticmethod
    def make_enemy_splitter(size=28):
        """分裂机 - 绿色，死后分裂成2个小侦察机"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        # 六边形
        pts = []
        for i in range(6):
            a = (i / 6) * math.pi * 2 - math.pi / 2
            pts.append((int(cx + math.cos(a) * size * 0.7), int(cy + math.sin(a) * size * 0.7)))
        pygame.draw.polygon(s, (20, 80, 40), pts)
        pygame.draw.polygon(s, GREEN, pts, 2)
        pygame.draw.circle(s, (100, 255, 150), (cx, cy), 6)
        pygame.draw.circle(s, WHITE, (cx, cy), 3)
        return s

    @staticmethod
    def make_boss(size=60):
        """Boss - 大型战舰"""
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx, cy = size, size
        # 主体
        body = [(cx, cy + size * 0.8), (cx - size * 0.5, cy + size * 0.5),
                (cx - size * 0.9, cy), (cx - size * 0.7, cy - size * 0.5),
                (cx - size * 0.3, cy - size * 0.7), (cx + size * 0.3, cy - size * 0.7),
                (cx + size * 0.7, cy - size * 0.5), (cx + size * 0.9, cy),
                (cx + size * 0.5, cy + size * 0.5)]
        pygame.draw.polygon(s, (60, 15, 15), body)
        pygame.draw.polygon(s, (200, 40, 40), body, 3)
        # 装甲板
        inner = [(cx - size * 0.4, cy - size * 0.2), (cx + size * 0.4, cy - size * 0.2),
                 (cx + size * 0.3, cy + size * 0.3), (cx - size * 0.3, cy + size * 0.3)]
        pygame.draw.polygon(s, (100, 20, 20), inner)
        pygame.draw.polygon(s, (180, 60, 60), inner, 1)
        # 核心
        pygame.draw.circle(s, (255, 50, 50), (cx, cy), int(size * 0.2))
        pygame.draw.circle(s, (255, 150, 100), (cx, cy), int(size * 0.12))
        pygame.draw.circle(s, WHITE, (cx, cy), int(size * 0.06))
        # 炮台
        for dx in [-0.6, -0.3, 0.3, 0.6]:
            px = int(cx + dx * size)
            py = int(cy + size * 0.4)
            pygame.draw.rect(s, (150, 40, 40), (px - 4, py - 4, 8, 12))
            pygame.draw.circle(s, ORANGE, (px, py + 6), 3)
        return s

    @staticmethod
    def make_flash(sprite, color=(255, 255, 255, 200)):
        """受击闪白剪影: 保留 sprite 的不透明轮廓, 透明区域保持透明"""
        m = pygame.mask.from_surface(sprite, threshold=10)
        out = pygame.Surface(sprite.get_size(), pygame.SRCALPHA)
        m.to_surface(surface=out, setcolor=color, unsetcolor=(0, 0, 0, 0))
        return out


# ===== 粒子系统 v2 =====
class Particle:
    __slots__ = ['x', 'y', 'vx', 'vy', 'color', 'life', 'max_life', 'size', 'gravity', 'drag']

    def __init__(self, x, y, color, speed=None, angle=None, life=None, size=None,
                 gravity=0, drag=0.96):
        self.x, self.y = x, y
        self.color = color
        spd = speed if speed is not None else rand_range(1, 6)
        ang = angle if angle is not None else rand_range(0, math.pi * 2)
        self.vx = math.cos(ang) * spd
        self.vy = math.sin(ang) * spd
        self.life = life or rand_range(0.2, 0.7)
        self.max_life = self.life
        self.size = size or rand_range(1.5, 4.5)
        self.gravity = gravity
        self.drag = drag

    def update(self, dt):
        self.x += self.vx * dt * 60
        self.y += self.vy * dt * 60
        self.vy += self.gravity * dt * 60
        self.vx *= self.drag
        self.vy *= self.drag
        self.life -= dt
        return self.life > 0

    def draw(self, surface):
        t = self.life / self.max_life
        r = max(1, int(self.size * t))
        c = tuple(int(v * t) for v in self.color)
        pygame.draw.circle(surface, c, (int(self.x), int(self.y)), r)


def explosion(particles, x, y, color, count=20, speed=7, size_range=(2, 5), life_range=(0.2, 0.6)):
    """标准爆炸"""
    for _ in range(count):
        particles.append(Particle(x, y, color,
                                  speed=rand_range(speed * 0.3, speed),
                                  size=rand_range(*size_range),
                                  life=rand_range(*life_range)))
    # 白闪核心
    for _ in range(count // 3):
        particles.append(Particle(x, y, WHITE,
                                  speed=rand_range(1, speed * 0.5),
                                  size=rand_range(1, 3), life=rand_range(0.05, 0.2)))


def big_explosion(particles, x, y, count=60):
    """大型爆炸（Boss/炸弹）"""
    colors = [WHITE, YELLOW, ORANGE, RED, (255, 200, 100)]
    for _ in range(count):
        c = random.choice(colors)
        particles.append(Particle(x, y, c,
                                  speed=rand_range(2, 14),
                                  size=rand_range(2, 8),
                                  life=rand_range(0.3, 1.2),
                                  gravity=0.05))
    # 碎片
    for _ in range(count // 2):
        particles.append(Particle(x, y, GRAY,
                                  speed=rand_range(3, 10),
                                  size=rand_range(1, 3),
                                  life=rand_range(0.5, 1.5),
                                  gravity=0.15, drag=0.98))


# ===== 背景系统 =====
class Background:
    """Small pre-rendered nebula plus cheap parallax stars for mobile."""
    def __init__(self):
        self.sky = pygame.image.load(os.path.join(ASSET_DIR, 'bg', 'space.jpg')).convert()
        if self.sky.get_size() != (SCREEN_W, SCREEN_H):
            self.sky = pygame.transform.smoothscale(self.sky, (SCREEN_W, SCREEN_H))
        self.stars = [[random.random()*SCREEN_W, random.random()*SCREEN_H,
                       random.choice((12, 22, 36))] for _ in range(40)]

    def update(self, dt):
        for star in self.stars:
            star[1] = (star[1] + star[2]*dt) % SCREEN_H

    def draw(self, surface):
        surface.blit(self.sky, (0, 0))
        for x, y, speed in self.stars:
            color = (126, 177, 198) if speed < 36 else (219, 232, 235)
            pygame.draw.circle(surface, color, (int(x), int(y)), 1)


# ===== 子弹 =====
_ORB_CACHE = {}


def _soft_orb(color, r):
    """预渲染径向衰减光珠 (衰减烘进 RGB, 供 BLEND_ADD 加算); 按 (color,r) 缓存"""
    r = max(1, int(r))
    key = (tuple(color), r)
    s = _ORB_CACHE.get(key)
    if s is None:
        s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        s.fill((0, 0, 0, 0))
        for rr in range(r, 0, -1):
            f = (1 - rr / r) ** 1.6
            pygame.draw.circle(s, (int(color[0] * f), int(color[1] * f),
                                   int(color[2] * f), 255), (r, r), rr)
        _ORB_CACHE[key] = s
    return s


_PLAQUE_CACHE = {}


def parchment(w, h):
    """概念图同款羊皮纸牌匾: 奶油底 + 圆角 + 双圈棕墨描边"""
    key = (w, h)
    s = _PLAQUE_CACHE.get(key)
    if s is None:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        s.fill((0, 0, 0, 0))
        r = pygame.Rect(0, 0, w, h)
        pygame.draw.rect(s, (9, 25, 43, 235), r, border_radius=9)
        pygame.draw.rect(s, (63, 127, 158, 255), r, width=2, border_radius=9)
        pygame.draw.rect(s, (29, 73, 100, 210), r.inflate(-6, -6),
                         width=1, border_radius=6)
        _PLAQUE_CACHE[key] = s
    return s


def plaque_blit(surface, text_surf, topleft=None, center=None, pad=(10, 5)):
    """把文字放进羊皮纸牌匾再贴到 surface; 返回牌匾 rect"""
    tw, th = text_surf.get_size()
    pl = parchment(tw + pad[0] * 2, th + pad[1] * 2)
    if center is not None:
        pr = pl.get_rect(center=center)
    else:
        pr = pl.get_rect(topleft=topleft)
    surface.blit(pl, pr)
    surface.blit(text_surf, (pr.x + pad[0], pr.y + pad[1]))
    return pr


class Bullet:
    __slots__ = ['x', 'y', 'vx', 'vy', 'damage', 'color', 'size', 'is_player',
                 'homing', 'dead', 'pierce', 'trail', 'time', 'owner']

    def __init__(self, x, y, vx, vy, damage=1, color=CYAN, size=3,
                 is_player=True, homing=False, pierce=False, owner=0):
        self.x, self.y = x, y
        self.vx, self.vy = vx, vy
        self.damage = damage
        self.color = color
        self.size = size
        self.is_player = is_player
        self.homing = homing
        self.pierce = pierce
        self.owner = owner
        self.dead = False
        self.trail = []
        self.time = 0

    def update(self, dt, targets=None):
        self.time += dt
        if self.homing and targets:
            closest, min_d = None, 250
            for t in targets:
                d = math.hypot(t.x - self.x, t.y - self.y)
                if d < min_d:
                    min_d, closest = d, t
            if closest:
                ang = math.atan2(closest.y - self.y, closest.x - self.x)
                spd = math.hypot(self.vx, self.vy)
                self.vx = lerp(self.vx, math.cos(ang) * spd, 0.08)
                self.vy = lerp(self.vy, math.sin(ang) * spd, 0.08)

        self.trail.append((self.x, self.y))
        if len(self.trail) > 6:
            self.trail.pop(0)
        self.x += self.vx * dt * 60
        self.y += self.vy * dt * 60
        if self.y < -30 or self.y > SCREEN_H + 30 or self.x < -30 or self.x > SCREEN_W + 30:
            self.dead = True

    # M8 方向C 光珠配色: 玩家金琥珀 / 敌方玫瑰余烬
    ORB_PLAYER = (255, 200, 110)
    ORB_ENEMY = (232, 96, 88)

    def draw(self, surface):
        base = self.ORB_PLAYER if self.is_player else self.ORB_ENEMY
        cx, cy = int(self.x), int(self.y)
        # 尾迹: 由旧到新渐隐的加算光点
        n = max(1, len(self.trail))
        for i, (tx, ty) in enumerate(self.trail):
            t = (i + 1) / n
            dim = tuple(int(v * t * 0.45) for v in base)
            r = max(1, int(self.size * t * 1.5))
            orb = _soft_orb(dim, r)
            surface.blit(orb, (int(tx) - r, int(ty) - r),
                         special_flags=pygame.BLEND_ADD)
        # 外层光晕 (加算)
        halo_r = self.size * 3
        halo = _soft_orb(tuple(int(v * 0.8) for v in base), halo_r)
        surface.blit(halo, (cx - halo_r, cy - halo_r),
                     special_flags=pygame.BLEND_ADD)
        # 弹体 + 亮白核 + 概念图同款墨水描边环
        pygame.draw.circle(surface, base, (cx, cy), self.size)
        pygame.draw.circle(surface, (255, 248, 235), (cx, cy),
                           max(1, self.size - 1))
        pygame.draw.circle(surface, (110, 84, 64), (cx, cy),
                           self.size + 1, width=max(1, self.size // 3))


# ===== 道具 =====
class PowerUp:
    TYPES = ['spread', 'missile_ammo', 'bomb', 'heal', 'shield', 'energy']
    COLORS = {'spread': YELLOW, 'missile_ammo': PURPLE, 'bomb': RED,
              'heal': GREEN, 'shield': CYAN, 'energy': BLUE}
    LABELS = {'spread': 'W', 'missile_ammo': 'M', 'bomb': 'B',
              'heal': '+', 'shield': 'S', 'energy': 'E'}

    def __init__(self, x, y, kind=None):
        self.x, self.y = x, y
        self.kind = kind or random.choice(self.TYPES)
        self.color = self.COLORS[self.kind]
        self.vy = 1.8
        self.dead = False
        self.time = 0
        self.size = 13

    def update(self, dt):
        self.time += dt
        self.y += self.vy * dt * 60
        self.x += math.sin(self.time * 3) * 0.4
        if self.y > SCREEN_H + 30:
            self.dead = True

    def draw(self, surface):
        pulse = 1 + math.sin(self.time * 8) * 0.12
        s = int(self.size * pulse)
        # 光晕
        glow = pygame.Surface((s * 4, s * 4), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*self.color, 35), (s * 2, s * 2), s * 2)
        surface.blit(glow, (int(self.x - s * 2), int(self.y - s * 2)))
        spr = ASSETS.get('pu_' + self.kind) if ASSETS else None
        if spr:
            scaled = pygame.transform.smoothscale(
                spr, (max(1, int(spr.get_width() * pulse)),
                      max(1, int(spr.get_height() * pulse))))
            surface.blit(scaled, scaled.get_rect(center=(int(self.x), int(self.y))))
            return
        # 菱形框 (无素材回退)
        pts = [(self.x, self.y - s), (self.x + s, self.y),
               (self.x, self.y + s), (self.x - s, self.y)]
        pygame.draw.polygon(surface, self.color, pts, 2)
        # 标签
        font = pygame.font.Font(None, 18)
        lbl = font.render(self.LABELS[self.kind], True, self.color)
        surface.blit(lbl, (int(self.x - lbl.get_width() / 2),
                          int(self.y - lbl.get_height() / 2)))


# ===== 敌机 =====
class Enemy:
    def __init__(self, x, y, kind, wave, sprites, formation_offset=None):
        self.x, self.y = x, y
        self.kind = kind
        self.wave = wave
        self.time = rand_range(0, 10)
        self.dead = False
        self.flash_timer = 0
        self.shoot_timer = rand_range(0.5, 2.0)
        self.formation_offset = formation_offset or (0, 0)
        self.formation_time = 0
        self.sprites = sprites

        # 护盾机特有
        self.shield_hp = 0

        cfg = self._get_config(kind, wave)
        self.hp = self.max_hp = cfg['hp']
        if kind == 'boss':
            self.hp = self.max_hp = int(cfg['hp'] * DIFF['bosshp'])
        self.speed = cfg['speed']
        self.size = cfg['size']
        self.color = cfg['color']
        self.score = cfg['score']
        self.shoot_interval = cfg['shoot_interval'] / DIFF['fire']
        self.move_pattern = cfg['move_pattern']
        self.shield_hp = cfg.get('shield_hp', 0)
        self.max_shield = self.shield_hp

        # Boss
        if kind == 'boss':
            self.phase = 0
            self.phase_timer = 0
            self.entry_y = 100
            ch = (wave - 1) // 5 + 1
            self.mod = boss_mod(ch) if CAMPAIGN['active'] else boss_mod(0)
            self.chapter = ch
            self.hp = self.max_hp = int(self.max_hp * self.mod['hp'])
            if self.mod['tint'] and self.sprites.get('boss'):
                key = ('boss_tint', ch)
                if key not in self.sprites:
                    self.sprites[key] = Assets.tint(self.sprites['boss'],
                                                    self.mod['tint'])

    def _get_config(self, kind, wave):
        w = min(wave, 30)
        configs = {
            'scout': {'hp': 3, 'speed': 3.5 + w * 0.1, 'size': 16, 'color': RED,
                      'score': 100, 'shoot_interval': 99, 'move_pattern': 'straight'},
            'fighter': {'hp': 6 + w, 'speed': 2.2 + w * 0.06, 'size': 22, 'color': ORANGE,
                        'score': 300, 'shoot_interval': max(0.7, 1.8 - w * 0.05),
                        'move_pattern': 'sine'},
            'bomber': {'hp': 15 + w * 2, 'speed': 1.3 + w * 0.04, 'size': 30, 'color': PURPLE,
                       'score': 600, 'shoot_interval': max(1.0, 2.2 - w * 0.06),
                       'move_pattern': 'zigzag'},
            'kamikaze': {'hp': 2, 'speed': 5 + w * 0.2, 'size': 14, 'color': PINK,
                         'score': 200, 'shoot_interval': 99, 'move_pattern': 'chase'},
            'shielded': {'hp': 8 + w, 'speed': 1.8, 'size': 24, 'color': BLUE,
                         'score': 400, 'shoot_interval': max(0.9, 2.0 - w * 0.05),
                         'move_pattern': 'sine', 'shield_hp': 10 + w * 2},
            'splitter': {'hp': 10 + w, 'speed': 1.5, 'size': 26, 'color': GREEN,
                         'score': 500, 'shoot_interval': max(1.0, 2.5 - w * 0.06),
                         'move_pattern': 'zigzag'},
            'boss': {'hp': 150 + w * 40, 'speed': 0.8, 'size': 55, 'color': DARK_RED,
                     'score': 8000, 'shoot_interval': 0.5, 'move_pattern': 'boss'},
        }
        return configs[kind]

    def update(self, dt, bullets, player_x, player_y):
        self.time += dt
        self.flash_timer = max(0, self.flash_timer - dt)
        self.formation_time += dt

        # 移动
        if self.move_pattern == 'straight':
            self.y += self.speed * dt * 60
        elif self.move_pattern == 'sine':
            self.y += self.speed * dt * 60
            self.x += math.sin(self.time * 2.5) * 1.8
        elif self.move_pattern == 'zigzag':
            self.y += self.speed * dt * 60
            self.x += math.cos(self.time * 1.8) * 2.2
        elif self.move_pattern == 'chase':
            angle = math.atan2(player_y - self.y, player_x - self.x)
            self.x += math.cos(angle) * self.speed * dt * 60 * 0.5
            self.y += self.speed * dt * 60
        elif self.move_pattern == 'boss':
            if self.y < self.entry_y:
                self.y += 1.0 * dt * 60
            else:
                self.x += math.sin(self.time * 0.7) * 1.8
                self.x = clamp(self.x, self.size + 20, SCREEN_W - self.size - 20)
                self.phase_timer += dt
                # 阶段切换
                hp_ratio = self.hp / self.max_hp
                if hp_ratio < 0.33:
                    self.phase = 2
                elif hp_ratio < 0.66:
                    self.phase = 1

        self.x = clamp(self.x, self.size, SCREEN_W - self.size)

        # 射击
        self.shoot_timer -= dt
        if self.shoot_timer <= 0 and self.y > 10 and self.y < SCREEN_H - 50:
            self.shoot_timer = self.shoot_interval
            self._shoot(bullets, player_x, player_y)

        if self.y > SCREEN_H + 80:
            self.dead = True

    def _shoot(self, bullets, px, py):
        if self.kind == 'scout' or self.kind == 'kamikaze':
            return
        elif self.kind == 'fighter' or self.kind == 'shielded':
            ang = math.atan2(py - self.y, px - self.x)
            bullets.append(Bullet(self.x, self.y + self.size * 0.5,
                                 math.cos(ang) * 4.5, math.sin(ang) * 4.5,
                                 damage=1, color=ORANGE, size=4, is_player=False))
        elif self.kind == 'bomber':
            for off in [-0.35, 0, 0.35]:
                ang = math.pi / 2 + off
                bullets.append(Bullet(self.x, self.y + self.size,
                                     math.cos(ang) * 3.5, math.sin(ang) * 3.5,
                                     damage=1, color=PURPLE, size=5, is_player=False))
        elif self.kind == 'splitter':
            for off in [-0.5, 0.5]:
                ang = math.pi / 2 + off
                bullets.append(Bullet(self.x, self.y + self.size,
                                     math.cos(ang) * 3, math.sin(ang) * 3,
                                     damage=1, color=GREEN, size=4, is_player=False))
        elif self.kind == 'boss':
            self._boss_shoot(bullets, px, py)

    def _boss_shoot(self, bullets, px, py):
        d = self.mod['density']
        sp = self.mod['spd']
        if self.phase == 0:
            # 圆形弹幕
            n = int(10 * d)
            for i in range(n):
                ang = (i / n) * math.pi * 2 + self.time * 0.5
                bullets.append(Bullet(self.x, self.y + 20,
                                     math.cos(ang) * 3 * sp, math.sin(ang) * 3 * sp,
                                     damage=1, color=RED, size=4, is_player=False))
        elif self.phase == 1:
            # 双螺旋 + 瞄准
            n = int(6 * d)
            for i in range(n):
                ang = (i / n) * math.pi * 2 + self.time * 2
                bullets.append(Bullet(self.x, self.y + 20,
                                     math.cos(ang) * 3.5 * sp, math.sin(ang) * 3.5 * sp,
                                     damage=1, color=ORANGE, size=4, is_player=False))
            aim = math.atan2(py - self.y, px - self.x)
            bullets.append(Bullet(self.x, self.y + 30,
                                 math.cos(aim) * 5.5 * sp, math.sin(aim) * 5.5 * sp,
                                 damage=2, color=YELLOW, size=6, is_player=False))
        else:
            # 狂暴: 扇形 + 螺旋 + 追踪
            for i in range(int(9 * d)):
                ang = math.pi / 2 + (i - 4) * 0.18
                bullets.append(Bullet(self.x, self.y + 20,
                                     math.cos(ang) * 4 * sp, math.sin(ang) * 4 * sp,
                                     damage=1, color=PINK, size=4, is_player=False))
            n = int(4 * d)
            for i in range(n):
                ang = (i / n) * math.pi * 2 - self.time * 3
                bullets.append(Bullet(self.x, self.y,
                                     math.cos(ang) * 2.8 * sp, math.sin(ang) * 2.8 * sp,
                                     damage=1, color=PURPLE, size=5, is_player=False,
                                     homing=True))

    def hit(self, damage):
        if self.shield_hp > 0:
            self.shield_hp -= damage
            self.flash_timer = 0.06
            if self.shield_hp <= 0:
                self.shield_hp = 0
            return False
        self.hp -= damage
        self.flash_timer = 0.06
        if self.hp <= 0:
            self.dead = True
            return True
        return False

    def draw(self, surface):
        sprite = None
        if self.kind == 'scout':
            sprite = self.sprites['scout']
        elif self.kind == 'fighter':
            sprite = self.sprites['fighter']
        elif self.kind == 'bomber':
            sprite = self.sprites['bomber']
        elif self.kind == 'kamikaze':
            sprite = self.sprites['kamikaze']
        elif self.kind == 'shielded':
            sprite = self.sprites['shielded']
        elif self.kind == 'splitter':
            sprite = self.sprites['splitter']
        elif self.kind == 'boss':
            sprite = self.sprites.get(('boss_tint', self.chapter),
                                      self.sprites['boss'])

        if sprite:
            surface.blit(sprite, (int(self.x - sprite.get_width() / 2),
                                  int(self.y - sprite.get_height() / 2)))
            if self.flash_timer > 0:
                # 受击闪白: 叠加预渲染白色剪影
                flash = self.sprites.get(self.kind + '_flash')
                if flash:
                    surface.blit(flash, (int(self.x - flash.get_width() / 2),
                                         int(self.y - flash.get_height() / 2)))

        # 护盾环
        if self.shield_hp > 0:
            alpha = int(60 + 40 * (self.shield_hp / max(1, self.max_shield)))
            sspr = ASSETS.get('shield_enemy') if ASSETS else None
            if sspr:
                d = int(self.size * 3.2)
                scaled = pygame.transform.smoothscale(sspr, (d, d))
                scaled = pygame.transform.rotate(scaled, 180)
                scaled.set_alpha(alpha)
                surface.blit(scaled, scaled.get_rect(center=(int(self.x), int(self.y))))
            else:
                shield_s = pygame.Surface((self.size * 4, self.size * 4), pygame.SRCALPHA)
                pygame.draw.circle(shield_s, (80, 160, 255, alpha),
                                 (self.size * 2, self.size * 2), int(self.size * 1.3), 2)
                surface.blit(shield_s, (int(self.x - self.size * 2), int(self.y - self.size * 2)))

        # Boss HP条
        if self.kind == 'boss' and not self.dead:
            bar_w = 200
            bx = SCREEN_W // 2 - bar_w // 2
            by = 50
            pygame.draw.rect(surface, (40, 40, 40), (bx, by, bar_w, 8))
            ratio = self.hp / self.max_hp
            bar_color = RED if ratio < 0.33 else ORANGE if ratio < 0.66 else YELLOW
            pygame.draw.rect(surface, bar_color, (bx, by, int(bar_w * ratio), 8))
            pygame.draw.rect(surface, WHITE, (bx, by, bar_w, 8), 1)
            # 阶段指示
            phase_font = Fonts.get(17)
            phase_txt = phase_font.render(T('boss_phase', self.phase + 1), True, WHITE)
            surface.blit(phase_txt, (bx + bar_w + 10, by - 3))

        # 自爆机闪烁
        if self.kind == 'kamikaze' and int(self.time * 8) % 2 == 0:
            pygame.draw.circle(surface, (*PINK, 80), (int(self.x), int(self.y)),
                             int(self.size * 1.5), 1)


# ===== 玩家 =====
class Player:
    def __init__(self, idx=0, solo=True):
        self.idx = idx
        if solo:
            self.x = SCREEN_W / 2
        else:
            self.x = SCREEN_W / 2 + (-70 if idx == 0 else 70)
        self.y = SCREEN_H - 100
        self.size = 22
        self.speed = 5.5
        self.hp = 6
        self.max_hp = 6
        self.lives = 3
        self.bombs = 3
        self.weapon = WPN_VULCAN
        self.shoot_level = 1
        self.energy = 100
        self.max_energy = 100
        self.missile_ammo = 6
        self.shield_timer = 0
        self.shoot_timer = 0
        self.invincible_timer = 0
        self.engine_time = 0
        self.combo = 0
        self.combo_timer = 0
        self.graze_count = 0
        self.damage_mult = 1.0
        self.fired = 0.0
        # M5 双人
        self.alive = True
        self.input_dead = False   # 命尽: HUD 置灰 + 输入失效, 但对象仍存活等队友
        self.respawn_timer = 0.0
        self.score = 0

    def update(self, dt, dx, dy, bullets, enemies):
        # 计时器无论是否活跃都要衰减, 保证复活倒计时/无敌/护盾/连击正常收尾
        self.shoot_timer -= dt
        self.fired = max(0, self.fired - dt)
        self.invincible_timer = max(0, self.invincible_timer - dt)
        self.shield_timer = max(0, self.shield_timer - dt)
        self.combo_timer = max(0, self.combo_timer - dt)
        if self.combo_timer <= 0:
            self.combo = 0
        if not self.alive or self.input_dead:
            return
        self.engine_time += dt * 15

        if dx and dy:
            dx *= 0.707; dy *= 0.707
        self.x += dx * self.speed * dt * 60
        self.y += dy * self.speed * dt * 60
        self.x = clamp(self.x, self.size, SCREEN_W - self.size)
        self.y = clamp(self.y, SCREEN_H * 0.25, SCREEN_H - self.size - 10)

        # 能量回复
        if self.weapon != WPN_LASER:
            self.energy = min(self.max_energy, self.energy + 12 * dt)

        # 自动射击
        interval = {WPN_VULCAN: 0.09, WPN_LASER: 0.05, WPN_MISSILE: 0.35}[self.weapon]
        if self.shoot_timer <= 0:
            self.shoot_timer = interval
            self.fired = 0.06
            self._shoot(bullets, enemies)

    def _shoot(self, bullets, enemies):
        bx, by = self.x, self.y - self.size
        dmg = self.damage_mult
        oi = self.idx

        if self.weapon == WPN_VULCAN:
            spd = -11
            lvl = self.shoot_level
            if lvl == 1:
                bullets.append(Bullet(bx, by, 0, spd, damage=1 * dmg, color=CYAN, size=3, owner=oi))
            elif lvl == 2:
                bullets.append(Bullet(bx - 5, by, 0, spd, damage=1 * dmg, color=CYAN, size=3, owner=oi))
                bullets.append(Bullet(bx + 5, by, 0, spd, damage=1 * dmg, color=CYAN, size=3, owner=oi))
            elif lvl == 3:
                bullets.append(Bullet(bx, by, 0, spd, damage=1 * dmg, color=CYAN, size=3, owner=oi))
                bullets.append(Bullet(bx - 10, by + 4, -1.3, spd, damage=1 * dmg, color=BLUE, size=3, owner=oi))
                bullets.append(Bullet(bx + 10, by + 4, 1.3, spd, damage=1 * dmg, color=BLUE, size=3, owner=oi))
            else:
                bullets.append(Bullet(bx - 4, by, -0.3, spd, damage=1 * dmg, color=CYAN, size=3, owner=oi))
                bullets.append(Bullet(bx + 4, by, 0.3, spd, damage=1 * dmg, color=CYAN, size=3, owner=oi))
                bullets.append(Bullet(bx - 12, by + 4, -1.8, spd * 0.95, damage=1 * dmg, color=BLUE, size=3, owner=oi))
                bullets.append(Bullet(bx + 12, by + 4, 1.8, spd * 0.95, damage=1 * dmg, color=BLUE, size=3, owner=oi))

        elif self.weapon == WPN_LASER:
            if self.energy > 0:
                self.energy -= 25 * 0.05  # 每发消耗
                bullets.append(Bullet(bx, by, 0, -16, damage=0.6 * dmg,
                                     color=GREEN, size=2, pierce=True, owner=oi))
            else:
                # 没能量自动切回
                self.weapon = WPN_VULCAN

        elif self.weapon == WPN_MISSILE:
            if self.missile_ammo > 0:
                self.missile_ammo -= 1
                bullets.append(Bullet(bx - 12, by + 8, -2, -7,
                                     damage=4 * dmg, color=PURPLE, size=5,
                                     homing=True, owner=oi))
                bullets.append(Bullet(bx + 12, by + 8, 2, -7,
                                     damage=4 * dmg, color=PURPLE, size=5,
                                     homing=True, owner=oi))
                if self.missile_ammo <= 0:
                    self.weapon = WPN_VULCAN

    def switch_weapon(self):
        self.weapon = (self.weapon + 1) % 3
        if self.weapon == WPN_LASER and self.energy < 10:
            self.weapon = WPN_VULCAN
        if self.weapon == WPN_MISSILE and self.missile_ammo <= 0:
            self.weapon = WPN_VULCAN

    def use_bomb(self, enemies, particles, bullets):
        if self.bombs <= 0:
            return False
        self.bombs -= 1
        for b in bullets:
            if not b.is_player:
                b.dead = True
        for e in enemies:
            e.hit(20)
            if e.dead:
                big_explosion(particles, e.x, e.y, 20)
        big_explosion(particles, self.x, self.y - 100, 80)
        return True

    def take_damage(self, dmg=1):
        if not self.alive or self.input_dead:
            return False
        if self.invincible_timer > 0:
            return False
        if self.shield_timer > 0:
            self.shield_timer = 0
            self.invincible_timer = 1.0
            return False
        self.hp -= dmg
        self.invincible_timer = 1.5
        self.shoot_level = max(1, self.shoot_level - 1)
        if self.hp <= 0:
            self.lives -= 1
            self.hp = self.max_hp
            self.invincible_timer = 3.0
            self.weapon = WPN_VULCAN
            return True
        return False

    def add_combo(self):
        self.combo += 1
        self.combo_timer = 2.5

    def draw(self, surface, sprite):
        if not self.alive:
            return
        if self.invincible_timer > 0 and int(self.invincible_timer * 12) % 2 == 0:
            return
        # 引擎火焰: 素材帧动画, 朝下
        flames = ASSETS.get('flame') if ASSETS else None
        if flames:
            fr = flames[int(self.engine_time * 12) % len(flames)]
            fr = pygame.transform.rotate(fr, 180)
            surface.blit(fr, fr.get_rect(
                midtop=(int(self.x), int(self.y + sprite.get_height() * 0.30))))
        else:
            flame = 14 + math.sin(self.engine_time) * 6
            pts = [(int(self.x - 6), int(self.y + self.size * 0.5)),
                   (int(self.x), int(self.y + self.size * 0.5 + flame)),
                   (int(self.x + 6), int(self.y + self.size * 0.5))]
            pygame.draw.polygon(surface, ORANGE, pts)
            inner = [(int(self.x - 3), int(self.y + self.size * 0.5)),
                     (int(self.x), int(self.y + self.size * 0.5 + flame * 0.55)),
                     (int(self.x + 3), int(self.y + self.size * 0.5))]
            pygame.draw.polygon(surface, WHITE, inner)
        # 机体
        surface.blit(sprite, (int(self.x - sprite.get_width() / 2),
                             int(self.y - sprite.get_height() / 2)))
        # 枪口火光
        if self.fired > 0 and ASSETS.get('glow'):
            g = pygame.transform.smoothscale(ASSETS['glow'], (36, 36))
            surface.blit(g, g.get_rect(center=(int(self.x), int(self.y - self.size))),
                         special_flags=pygame.BLEND_ADD)
        # 低血量损伤贴层
        dmg_key = 'player2_damage' if self.idx == 1 else 'player_damage'
        dmg = ASSETS.get(dmg_key) or ASSETS.get('player_damage')
        if self.hp == 1 and dmg:
            surface.blit(dmg, (int(self.x - dmg.get_width() / 2),
                              int(self.y - dmg.get_height() / 2)))
        # 护盾
        if self.shield_timer > 0:
            a = int(70 + 40 * math.sin(pygame.time.get_ticks() * 0.008))
            sspr = ASSETS.get('shield') if ASSETS else None
            if sspr:
                d = int(self.size * 4.2)
                scaled = pygame.transform.smoothscale(sspr, (d, d))
                scaled.set_alpha(clamp(a, 0, 255))
                surface.blit(scaled, scaled.get_rect(center=(int(self.x), int(self.y))))
            else:
                ss = pygame.Surface((self.size * 5, self.size * 5), pygame.SRCALPHA)
                pygame.draw.circle(ss, (0, 220, 255, a),
                                 (self.size * 2 + self.size // 2, self.size * 2 + self.size // 2),
                                 int(self.size * 1.8), 2)
                surface.blit(ss, (int(self.x - self.size * 2.5), int(self.y - self.size * 2.5)))

        # 擦弹判定圈（调试可视化，正式版隐藏）
        # pygame.draw.circle(surface, WHITE, (int(self.x), int(self.y)), 4, 1)


# ===== 编队系统 =====
class Formation:
    """生成一组按编队飞行的敌机"""

    @staticmethod
    def spawn_v(enemies, kind, wave, sprites, cx=None, count=5):
        cx = cx or SCREEN_W / 2
        for i in range(count):
            offset_x = (i - count // 2) * 45
            offset_y = abs(i - count // 2) * 30
            enemies.append(Enemy(cx + offset_x, -40 - offset_y, kind, wave, sprites))

    @staticmethod
    def spawn_line(enemies, kind, wave, sprites, count=4):
        spacing = SCREEN_W / (count + 1)
        for i in range(count):
            enemies.append(Enemy(spacing * (i + 1), -40 - i * 15, kind, wave, sprites))

    @staticmethod
    def spawn_circle(enemies, kind, wave, sprites, count=6):
        cx, cy = SCREEN_W / 2, -80
        for i in range(count):
            ang = (i / count) * math.pi * 2
            enemies.append(Enemy(cx + math.cos(ang) * 60, cy + math.sin(ang) * 60,
                               kind, wave, sprites))

    @staticmethod
    def spawn_random(enemies, kind, wave, sprites, count=3):
        for _ in range(count):
            enemies.append(Enemy(rand_range(40, SCREEN_W - 40), rand_range(-100, -30),
                               kind, wave, sprites))


# ===== 波次管理 =====
class WaveManager:
    def __init__(self):
        self.wave = 0
        self.spawn_queue = []
        self.spawn_timer = 0
        self.between_waves = True
        self.wave_delay = 2.5
        self.banner_timer = 0
        self.shop_open = False

    def start_next_wave(self):
        self.wave += 1
        self.between_waves = False
        self.banner_timer = 2.5
        self.spawn_queue = self._generate_wave(self.wave)
        self.spawn_timer = 0

    def _generate_wave(self, wave):
        """生成波次的敌人队列"""
        queue = []
        if wave % 5 == 0:
            # Boss 波
            queue.append(('boss', 0, SCREEN_W / 2))
            # Boss 带小弟
            for i in range(3):
                queue.append(('scout', 2 + i * 1.5, rand_range(60, SCREEN_W - 60)))
        else:
            budget = int((3 + wave * 2) * DIFF['budget'])
            while budget > 0:
                delay = rand_range(0.5, 1.5)
                if wave >= 3 and random.random() < 0.25:
                    # 编队
                    formation = random.choice(['v', 'line', 'circle'])
                    kind = 'scout' if wave < 4 else random.choice(['scout', 'fighter'])
                    count = random.randint(3, 5)
                    if formation == 'v':
                        for i in range(count):
                            queue.append((kind, delay + i * 0.15, SCREEN_W / 2 + (i - count // 2) * 45))
                    elif formation == 'line':
                        for i in range(count):
                            queue.append((kind, delay + i * 0.2, 60 + i * (SCREEN_W - 120) / max(1, count - 1)))
                    else:
                        for i in range(count):
                            ang = (i / count) * math.pi * 2
                            queue.append((kind, delay, SCREEN_W / 2 + math.cos(ang) * 70))
                    budget -= count
                else:
                    # 单体
                    kinds = ['scout']
                    if wave >= 2: kinds.append('fighter')
                    if wave >= 4: kinds.append('kamikaze')
                    if wave >= 5: kinds.append('bomber')
                    if wave >= 6: kinds.append('shielded')
                    if wave >= 8: kinds.append('splitter')
                    kind = random.choice(kinds)
                    cost = {'scout': 1, 'fighter': 2, 'kamikaze': 1, 'bomber': 3,
                            'shielded': 3, 'splitter': 3}[kind]
                    queue.append((kind, delay, rand_range(40, SCREEN_W - 40)))
                    budget -= cost
        return queue

    def update(self, dt, enemies, sprites):
        if self.banner_timer > 0:
            self.banner_timer -= dt

        if self.between_waves:
            if not self.shop_open:
                self.wave_delay -= dt
                if self.wave_delay <= 0:
                    self.start_next_wave()
            return

        # 按队列生成
        self.spawn_timer += dt
        while self.spawn_queue and self.spawn_timer >= self.spawn_queue[0][1]:
            kind, _, x = self.spawn_queue.pop(0)
            enemies.append(Enemy(x, -40, kind, self.wave, sprites))

        # 波次结束
        if not self.spawn_queue and len(enemies) == 0:
            self.between_waves = True
            self.shop_open = True  # 打开商店
            self.wave_delay = 30  # 商店不限时

    def wave_complete(self):
        return self.between_waves and not self.shop_open


# ===== 商店 =====
class Shop:
    ITEMS = [
        {'name': 'it_hp', 'cost': 2000, 'desc': 'it_hp_d', 'action': 'hp'},
        {'name': 'it_dmg', 'cost': 3000, 'desc': 'it_dmg_d', 'action': 'damage'},
        {'name': 'it_spd', 'cost': 1500, 'desc': 'it_spd_d', 'action': 'speed'},
        {'name': 'it_bomb', 'cost': 2500, 'desc': 'it_bomb_d', 'action': 'bomb'},
        {'name': 'it_mis', 'cost': 2000, 'desc': 'it_mis_d', 'action': 'missile'},
        {'name': 'it_skip', 'cost': 0, 'desc': 'it_skip_d', 'action': 'skip'},
    ]

    def __init__(self):
        self.selected = 0
        self.active = False

    def open(self):
        self.active = True
        self.selected = 0

    def close(self):
        self.active = False

    def apply(self, players, score, coop=False):
        """返回 (新队伍总分, 是否购买成功)
        coop=True 时价格 ×1.6, 属性类双人同时生效, 消耗类各发一份。"""
        item = self.ITEMS[self.selected]
        cost = int(item['cost'] * (1.6 if coop else 1.0))
        if cost > score:
            return score, False
        score -= cost
        action = item['action']
        targets = players if coop else [players[0]]
        if action == 'hp':
            for p in targets:
                p.max_hp += 2
                p.hp = p.max_hp
        elif action == 'damage':
            for p in targets:
                p.damage_mult *= 1.3
        elif action == 'speed':
            for p in targets:
                p.speed = min(8, p.speed + 0.5)
        elif action == 'bomb':
            for p in targets:
                p.bombs = min(5, p.bombs + 1)
        elif action == 'missile':
            for p in targets:
                p.missile_ammo += 4
        return score, True

    def cost_of(self, idx, coop=False):
        return int(self.ITEMS[idx]['cost'] * (1.6 if coop else 1.0))


# ===== 游戏主体 =====
class Game:
    STATE_MENU = 0
    STATE_PLAYING = 1
    STATE_PAUSED = 2
    STATE_GAMEOVER = 3
    STATE_SHOP = 4
    STATE_SETTINGS = 5
    STATE_MODESEL = 6
    STATE_DIFFSEL = 7
    STATE_HELP = 8
    STATE_VICTORY = 9
    STATE_INTER = 10

    def __init__(self):
        pygame.init()
        Config.load()
        SaveData.load()
        Fonts.init()
        Audio.init()
        Audio.apply_volumes()
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption('Sky Strike v3 - 雷霆战机')
        self.clock = pygame.time.Clock()
        # M6: 统一输入层 (keyboard / touch), 平台自动检测
        self.platform = detect_platform()
        self.input = (TouchInput(self) if self.platform == 'touch'
                      else KeyboardInput(self))
        self.font_l = Fonts.get(52, title=True)
        self.font_m = Fonts.get(26, bold=True)
        self.font_s = Fonts.get(19)
        self.font_xs = Fonts.get(16)
        self._vignette = self._make_vignette()
        self._paper = self._make_paper()
        self.state = self.STATE_MENU
        self.high_score = SaveData.data['endless']['high']
        self.settings_sel = 0
        self.settings_return = self.STATE_MENU
        self.mode = 'endless'
        self.mode_coop = False
        self.new_record = False
        self.menu_sel = 0
        self.modesel_sel = 0
        self.diffsel_sel = 1
        self.pause_sel = 0
        self.pending_mode = 'endless'
        self.difficulty = 'normal'
        self.help_return = self.STATE_MENU
        self.quit_flag = False
        self.screen_shake = 0
        self.screen_flash = 0
        self.time = 0
        self.hitstop = 0
        self.popups = []
        self._boom_cache = {}
        self.shoot_sfx_cd = 0

        # 预渲染精灵: 优先 Kenney CC0 素材, 缺失回退程序化
        if Assets.available():
            self.sprites = Assets.build()
            ASSETS.clear()
            ASSETS.update(self.sprites)
        else:
            self.sprites = {
                'player': SpriteFactory.make_player_ship(),
                'player2': SpriteFactory.make_player_ship(),
                'scout': SpriteFactory.make_enemy_scout(),
                'fighter': SpriteFactory.make_enemy_fighter(),
                'bomber': SpriteFactory.make_enemy_bomber(),
                'kamikaze': SpriteFactory.make_enemy_kamikaze(),
                'shielded': SpriteFactory.make_enemy_shield(),
                'splitter': SpriteFactory.make_enemy_splitter(),
                'boss': SpriteFactory.make_boss(),
            }
        for kind in ('player', 'player2', 'scout', 'fighter', 'bomber',
                     'kamikaze', 'shielded', 'splitter', 'boss'):
            self.sprites[kind + '_flash'] = SpriteFactory.make_flash(self.sprites[kind])
        self.reset()

    def reset(self):
        coop = getattr(self, 'mode_coop', False)
        self.players = [Player(idx=0, solo=not coop)]
        if coop:
            self.players.append(Player(idx=1, solo=False))
        self.player = self.players[0]   # 兼容别名: 大量既有路径读 self.player
        self.enemies = []
        self.bullets = []
        self.powerups = []
        self.particles = []
        self.booms = []
        self.meteors = []
        self.meteor_timer = 4.0
        self.bg = Background()
        self.wave_mgr = WaveManager()
        self.shop = Shop()
        self.score = 0
        self.time = 0
        self.screen_shake = 0
        self.screen_flash = 0
        self.popups = []
        self.hitstop = 0
        for p in self.players:
            p.lives = DIFF['lives']
        # M3 提示系统
        self.hint_timer = 10.0
        self.toast = None
        self.heartbeat_timer = 0.0
        self._last_mult = 1
        # M4 战役
        self.pending_inter = False
        self.inter_stats = None
        self.victory_stats = None
        self.chapter_start_score = 0
        self.chapter_start_time = 0.0
        self.max_combo = 0
        self.boss_summon_timer = 0.0
        # M5 双人复活计时(每玩家一个)
        self.respawn_timers = [0.0, 0.0]

    def _toast(self, key):
        """一次性情境提示(存档级只弹一次)"""
        seen = Config.get('toasts') or {}
        if seen.get(key):
            return
        seen[key] = True
        Config.set('toasts', seen)
        self.toast = {'key': key, 't': 3.0}

    async def run(self):
        running = True
        # 打包自检: SK_SMOKE_FRAMES=N 跑 N 帧后自动退出, 可选 SK_SMOKE_SHOT 存截图
        smoke = int(os.environ.get('SK_SMOKE_FRAMES', '') or 0)
        if smoke:
            print(f"[smoke] platform={self.platform} assets={len(ASSETS)} "
                  f"state={self.state}", flush=True)
        while running:
            dt = min(self.clock.tick(FPS) / 1000.0, 0.04)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    self._on_key(event.key)
                # M6: 统一输入层 (keyboard / touch) 事件入口
                self.input.handle_event(event)
            self._drain_touch()
            if self.quit_flag:
                running = False
                break
            # M6: 每帧轮询移动向量 (键盘轮询 / 触控拖拽)
            self.input.poll()
            self._update(dt)
            self._draw()
            await asyncio.sleep(0)
            if smoke:
                smoke -= 1
                if smoke <= 0:
                    shot = os.environ.get('SK_SMOKE_SHOT')
                    if shot:
                        pygame.image.save(self.screen, shot)
                        print(f"[smoke] shot saved: {shot}", flush=True)
                    running = False
        if sys.platform != "emscripten":
            pygame.quit()

    def _drain_touch(self):
        """M6: 触控点按 → 复用键盘选择逻辑 (confirm=回车, back=Esc); 游戏内走屏上按钮."""
        if self.input.kind != 'touch' or self.state == self.STATE_PLAYING:
            return
        if self.input.consume('confirm'):
            self._on_key(pygame.K_r if self.state in
                         (self.STATE_GAMEOVER, self.STATE_VICTORY)
                         else pygame.K_RETURN)
        if self.input.consume('back'):
            self._on_key(pygame.K_ESCAPE)

    def _on_key(self, key):
        if key == pygame.K_m:
            Audio.toggle()
            return
        # M5 双人: 非游戏内状态下 P2 的 RShift 等价回车(任一方均可推进菜单)
        if self.mode_coop and key == pygame.K_RSHIFT \
                and self.state != self.STATE_PLAYING:
            key = pygame.K_RETURN
        if self.state == self.STATE_MENU:
            if key == pygame.K_UP or key == pygame.K_w:
                self.menu_sel = (self.menu_sel - 1) % 4
                Audio.play('beep_01')
            elif key == pygame.K_DOWN or key == pygame.K_s:
                self.menu_sel = (self.menu_sel + 1) % 4
                Audio.play('beep_01')
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                if self.menu_sel == 0:
                    self.modesel_sel = 0
                    self.state = self.STATE_MODESEL
                    Audio.play('beep_01')
                elif self.menu_sel == 1:
                    self.help_return = self.STATE_MENU
                    self.state = self.STATE_HELP
                    Audio.play('beep_01')
                elif self.menu_sel == 2:
                    self._open_settings(self.STATE_MENU)
                else:
                    self.quit_flag = True
        elif self.state == self.STATE_PLAYING:
            if key == pygame.K_p:
                self.state = self.STATE_PAUSED
                return
            # 单人: Space/Q/1/2/3 → P1
            if not self.mode_coop:
                if key == pygame.K_SPACE:
                    if self.player.use_bomb(self.enemies, self.particles, self.bullets):
                        self.screen_shake = 0.6
                        self.screen_flash = 0.3
                        Audio.play('explosion_01')
                elif key == pygame.K_q:
                    self.player.switch_weapon()
                elif key == pygame.K_1:
                    self.player.weapon = WPN_VULCAN
                elif key == pygame.K_2:
                    if self.player.energy >= 10: self.player.weapon = WPN_LASER
                elif key == pygame.K_3:
                    if self.player.missile_ammo > 0: self.player.weapon = WPN_MISSILE
                return
            # 双人: P1 = Space/Q/1/2/3, P2 = RShift/RCtrl/KP1-3
            def _act(p, act):
                if not p.alive or p.input_dead:
                    return
                if act == 'bomb':
                    if p.use_bomb(self.enemies, self.particles, self.bullets):
                        self.screen_shake = 0.6
                        self.screen_flash = 0.3
                        Audio.play('explosion_01')
                elif act == 'cycle':
                    p.switch_weapon()
                elif act == 'w1':
                    p.weapon = WPN_VULCAN
                elif act == 'w2':
                    if p.energy >= 10: p.weapon = WPN_LASER
                elif act == 'w3':
                    if p.missile_ammo > 0: p.weapon = WPN_MISSILE
            p1, p2 = self.players[0], (self.players[1] if len(self.players) > 1 else None)
            if key == pygame.K_SPACE:
                _act(p1, 'bomb')
            elif key == pygame.K_q:
                _act(p1, 'cycle')
            elif key == pygame.K_1:
                _act(p1, 'w1')
            elif key == pygame.K_2:
                _act(p1, 'w2')
            elif key == pygame.K_3:
                _act(p1, 'w3')
            elif p2 is not None:
                if key == pygame.K_RSHIFT:
                    _act(p2, 'bomb')
                elif key == pygame.K_RCTRL:
                    _act(p2, 'cycle')
                elif key == pygame.K_KP1:
                    _act(p2, 'w1')
                elif key == pygame.K_KP2:
                    _act(p2, 'w2')
                elif key == pygame.K_KP3:
                    _act(p2, 'w3')
        elif self.state == self.STATE_PAUSED:
            if key == pygame.K_p or key == pygame.K_ESCAPE:
                self.state = self.STATE_PLAYING
            elif key == pygame.K_UP or key == pygame.K_w:
                self.pause_sel = (self.pause_sel - 1) % 5
                Audio.play('beep_01')
            elif key == pygame.K_DOWN or key == pygame.K_s:
                self.pause_sel = (self.pause_sel + 1) % 5
                Audio.play('beep_01')
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                if self.pause_sel == 0:
                    self.state = self.STATE_PLAYING
                elif self.pause_sel == 1:
                    self._start_game()
                elif self.pause_sel == 2:
                    self.help_return = self.STATE_PAUSED
                    self.state = self.STATE_HELP
                elif self.pause_sel == 3:
                    self._open_settings(self.STATE_PAUSED)
                else:
                    self.state = self.STATE_MENU
                    Audio.music()
        elif self.state == self.STATE_GAMEOVER:
            if key == pygame.K_r:
                self._start_game()
            elif key == pygame.K_ESCAPE:
                self.state = self.STATE_MENU
        elif self.state == self.STATE_SHOP:
            if key == pygame.K_UP or key == pygame.K_w:
                self.shop.selected = (self.shop.selected - 1) % len(Shop.ITEMS)
            elif key == pygame.K_DOWN or key == pygame.K_s:
                self.shop.selected = (self.shop.selected + 1) % len(Shop.ITEMS)
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                item = Shop.ITEMS[self.shop.selected]
                if item['action'] == 'skip':
                    self.shop.close()
                    self.wave_mgr.shop_open = False
                    self.wave_mgr.wave_delay = 2.0
                    self.state = self.STATE_PLAYING
                else:
                    new_score, ok = self.shop.apply(self.players, self.score,
                                                    coop=self.mode_coop)
                    if ok:
                        # 从玩家个人分数中扣除, 保持 self.score = sum(p.score)
                        spent = self.score - new_score
                        # 按当前分数比例分摊到各玩家
                        total = sum(p.score for p in self.players) or 1
                        remain = spent
                        for i, p in enumerate(self.players):
                            if i == len(self.players) - 1:
                                cut = remain
                            else:
                                cut = int(spent * p.score / total)
                                remain -= cut
                            p.score = max(0, p.score - cut)
                        self.score = sum(p.score for p in self.players)
            elif key == pygame.K_ESCAPE:
                self.shop.close()
                self.wave_mgr.shop_open = False
                self.wave_mgr.wave_delay = 2.0
                self.state = self.STATE_PLAYING
        elif self.state == self.STATE_SETTINGS:
            if key == pygame.K_ESCAPE:
                self.state = self.settings_return
            elif key == pygame.K_UP or key == pygame.K_w:
                self.settings_sel = (self.settings_sel - 1) % 5
                Audio.play('beep_01')
            elif key == pygame.K_DOWN or key == pygame.K_s:
                self.settings_sel = (self.settings_sel + 1) % 5
                Audio.play('beep_01')
            elif key in (pygame.K_LEFT, pygame.K_a):
                self._adjust_setting(-1)
            elif key in (pygame.K_RIGHT, pygame.K_d):
                self._adjust_setting(1)
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                if self.settings_sel == 4:
                    self.state = self.settings_return
                else:
                    self._adjust_setting(1)
        elif self.state == self.STATE_MODESEL:
            n = len(self._mode_entries())
            if key == pygame.K_ESCAPE:
                self.state = self.STATE_MENU
            elif key == pygame.K_UP or key == pygame.K_w:
                self.modesel_sel = (self.modesel_sel - 1) % n
                Audio.play('beep_01')
            elif key == pygame.K_DOWN or key == pygame.K_s:
                self.modesel_sel = (self.modesel_sel + 1) % n
                Audio.play('beep_01')
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.pending_mode = ('campaign', 'endless', 'coop')[self.modesel_sel]
                self.diffsel_sel = 1
                self.state = self.STATE_DIFFSEL
                Audio.play('beep_01')
        elif self.state == self.STATE_DIFFSEL:
            if key == pygame.K_ESCAPE:
                self.state = self.STATE_MODESEL
            elif key == pygame.K_UP or key == pygame.K_w:
                self.diffsel_sel = (self.diffsel_sel - 1) % 3
                Audio.play('beep_01')
            elif key == pygame.K_DOWN or key == pygame.K_s:
                self.diffsel_sel = (self.diffsel_sel + 1) % 3
                Audio.play('beep_01')
            elif key in (pygame.K_RETURN, pygame.K_SPACE):
                self.difficulty = ('easy', 'normal', 'hell')[self.diffsel_sel]
                apply_difficulty(self.difficulty)
                self._start_game()
        elif self.state == self.STATE_HELP:
            if key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE):
                self.state = self.help_return
        elif self.state == self.STATE_INTER:
            if key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE):
                self.chapter_start_score = self.score
                self.chapter_start_time = self.time
                self.shop.open()
                self.state = self.STATE_SHOP
                Audio.play('beep_01')
        elif self.state == self.STATE_VICTORY:
            if key == pygame.K_r:
                self._start_game()
            elif key == pygame.K_ESCAPE:
                self.state = self.STATE_MENU
                Audio.music()

    def _start_game(self):
        self.mode = self.pending_mode
        self.mode_coop = (self.mode == 'coop')
        CAMPAIGN['active'] = (self.mode == 'campaign')
        self.reset()
        Audio.music()
        self.state = self.STATE_PLAYING
        if not Config.get('tutorial_seen'):
            Config.set('tutorial_seen', True)
            self.help_return = self.STATE_PLAYING
            self.state = self.STATE_HELP

    def _open_settings(self, return_state):
        self.settings_return = return_state
        self.settings_sel = 0
        self.state = self.STATE_SETTINGS
        Audio.play('beep_01')

    def _adjust_setting(self, delta):
        sel = self.settings_sel
        if sel in (0, 1, 2):
            key = ('vol_master', 'vol_music', 'vol_sfx')[sel]
            Config.set(key, clamp(Config.get(key) + delta, 0, 10))
            Audio.apply_volumes()
            Audio.play('beep_01')
        elif sel == 3:
            Config.set('shake', not Config.get('shake'))
            Audio.play('beep_01')
        Config.save()

    def _set_volume(self, row, val):
        """M6 触控: 点音量条直接设值 (0-10)."""
        key = ('vol_master', 'vol_music', 'vol_sfx')[row]
        Config.set(key, clamp(val, 0, 10))
        Audio.apply_volumes()
        Audio.play('beep_01')
        Config.save()

    def _record_run(self, cleared=False):
        """结算写档: 各模式最高分 / 通关标记"""
        self.new_record = self.score > self.high_score and self.score > 0
        SaveData.record(self.mode, self.score, wave=self.wave_mgr.wave,
                        cleared=cleared)
        if self.mode == 'endless':
            self.high_score = SaveData.data['endless']['high']

    def _update(self, dt):
        self.time += dt
        self.bg.update(dt)
        self.particles = [p for p in self.particles if p.update(dt)]
        for b in self.booms:
            b['t'] += dt
            b['i'] = int(b['t'] * 30)
        self.booms = [b for b in self.booms if b['i'] < b['n']]
        self.screen_shake = max(0, self.screen_shake - dt * 3)
        self.screen_flash = max(0, self.screen_flash - dt * 4)
        for pp in self.popups:
            pp['y'] -= 40 * dt
            pp['life'] -= dt
        self.popups = [pp for pp in self.popups if pp['life'] > 0]

        if self.state != self.STATE_PLAYING:
            return

        # 打击停顿: 短暂冻结增强冲击感
        if self.hitstop > 0:
            self.hitstop -= dt
            return

        # 队伍总分 (M5): 单人 = P1 分, 双人 = P1+P2
        self.score = sum(p.score for p in self.players)

        # M3: 开局提示条 / toast 计时 / 低 HP 心跳 / combo 倍率首触
        self.hint_timer = max(0, self.hint_timer - dt)
        if self.toast:
            self.toast['t'] -= dt
            if self.toast['t'] <= 0:
                self.toast = None
        active = [p for p in self.players if p.alive and not p.input_dead]
        any_mult = 1
        for p in active:
            if p.combo >= 3:
                any_mult = max(any_mult, min(10, 1 + p.combo // 3))
        if any_mult >= 3 and self._last_mult < 3:
            self._toast('combo')
        self._last_mult = any_mult
        if any(p.alive and not p.input_dead and p.hp <= 2 for p in self.players):
            self.heartbeat_timer -= dt
            if self.heartbeat_timer <= 0:
                self.heartbeat_timer = 0.9
                Audio.play('heartbeat')
        else:
            self.heartbeat_timer = 0.0

        self.shoot_sfx_cd = max(0, self.shoot_sfx_cd - dt)
        if any(p.fired > 0 for p in active) and self.shoot_sfx_cd <= 0:
            self.shoot_sfx_cd = 0.09
            any_missile = any(p.weapon == WPN_MISSILE and p.fired > 0 for p in active)
            Audio.play('rocket_01' if any_missile else 'retro_laser_01')

        keys = pygame.key.get_pressed()

        # 复活倒计时 (M5 coop)
        for p in self.players:
            if not p.alive and not p.input_dead:
                p.respawn_timer -= dt
                if p.respawn_timer <= 0:
                    p.alive = True
                    p.x = SCREEN_W / 2 + (-70 if p.idx == 0 else 70) \
                        if self.mode_coop else SCREEN_W / 2
                    p.y = SCREEN_H - 60
                    p.invincible_timer = 2.0
                    Audio.play('retro_beep_04')

        # 输入映射 (M6): 触控 = 拖拽向量; 键盘 = 单人合并 / 双人拆分
        def _axis(kmap):
            dx, dy = 0, 0
            if keys[kmap['left']]:  dx -= 1
            if keys[kmap['right']]: dx += 1
            if keys[kmap['up']]:    dy -= 1
            if keys[kmap['down']]:  dy += 1
            return dx, dy

        if self.input.kind == 'touch':
            # 触控: 单人, 移动向量来自拖拽
            maps = [{'_pre': self.input.get_move()}]
        elif self.mode_coop:
            p1_map = {'left': pygame.K_a, 'right': pygame.K_d,
                      'up': pygame.K_w, 'down': pygame.K_s}
            p2_map = {'left': pygame.K_LEFT, 'right': pygame.K_RIGHT,
                      'up': pygame.K_UP, 'down': pygame.K_DOWN}
            maps = [p1_map, p2_map]
        else:
            # 单人: WASD 或方向键任一都行, 手工合并
            dx = dy = 0
            if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx -= 1
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx += 1
            if keys[pygame.K_UP] or keys[pygame.K_w]: dy -= 1
            if keys[pygame.K_DOWN] or keys[pygame.K_s]: dy += 1
            maps = [{'_pre': (dx, dy)}]

        for i, p in enumerate(self.players):
            if i < len(maps):
                m = maps[i]
                if '_pre' in m:
                    dx, dy = m['_pre']
                else:
                    dx, dy = _axis(m)
            else:
                dx, dy = 0, 0
            p.update(dt, dx, dy, self.bullets, self.enemies)

        # M6 触控: 消费一次性动作 (炸弹/切武器/暂停)
        if self.input.kind == 'touch':
            p1 = self.players[0]
            if self.input.consume('bomb'):
                if p1.alive and not p1.input_dead and \
                        p1.use_bomb(self.enemies, self.particles, self.bullets):
                    self.screen_shake = 0.6
                    self.screen_flash = 0.3
                    Audio.play('explosion_01')
            if self.input.consume('cycle'):
                if p1.alive and not p1.input_dead:
                    p1.switch_weapon()
            if self.input.consume('pause'):
                self.state = self.STATE_PAUSED

        self.wave_mgr.update(dt, self.enemies, self.sprites)

        # 检查商店
        if self.wave_mgr.shop_open and self.state == self.STATE_PLAYING:
            self.shop.open()
            self.state = self.STATE_SHOP
            Audio.play('beep_01')
            self._toast('shop')

        # 敌人瞄准最近 alive 玩家; 全部失活回退 P1
        tgt = None
        if active:
            # 用 P1 作为默认基准, 逐敌人取最近
            tgt = None  # per-enemy 决策
        for e in self.enemies:
            if active:
                nearest = min(active,
                              key=lambda p: (p.x - e.x) ** 2 + (p.y - e.y) ** 2)
                tx, ty = nearest.x, nearest.y
            else:
                tx, ty = self.player.x, self.player.y
            e.update(dt, self.bullets, tx, ty)

        # 分裂机死亡处理
        new_enemies = []
        for e in self.enemies:
            if e.dead and e.kind == 'splitter':
                for _ in range(2):
                    new_enemies.append(Enemy(e.x + rand_range(-20, 20), e.y,
                                           'scout', self.wave_mgr.wave, self.sprites))
        self.enemies.extend(new_enemies)
        self.enemies = [e for e in self.enemies if not e.dead]

        # 敌方追踪弹目标 = 所有 alive 玩家
        enemy_homing_targets = [p for p in self.players
                                if p.alive and not p.input_dead] or [self.player]
        for b in self.bullets:
            b.update(dt, self.enemies if (b.homing and b.is_player) else
                     (enemy_homing_targets if b.homing and not b.is_player else None))
        self.bullets = [b for b in self.bullets if not b.dead]

        for p in self.powerups:
            p.update(dt)
        self.powerups = [p for p in self.powerups if not p.dead]

        self._update_meteors(dt)

        self._collisions()

        # 击杀分数记在各玩家身上, 此处刷新队伍总分供本帧结算/绘制使用
        self.score = sum(p.score for p in self.players)

        # M4 战役: 连杀峰值 / Boss 召唤小弟 / 章末过场与通关
        for p in self.players:
            if p.combo > self.max_combo:
                self.max_combo = p.combo
        boss = next((e for e in self.enemies
                     if e.kind == 'boss' and not e.dead), None)
        if boss is not None and CAMPAIGN['active']:
            self.boss_summon_timer -= dt
            if self.boss_summon_timer <= 0:
                self.boss_summon_timer = boss.mod['summon']
                Formation.spawn_random(self.enemies, 'scout',
                                       self.wave_mgr.wave, self.sprites, count=2)
        for e in self.enemies:
            if e.dead and e.kind == 'boss' and not getattr(e, '_death_hooked', False):
                e._death_hooked = True
                self._on_boss_dead(e)
        if self.pending_inter and not self.enemies \
                and self.state == self.STATE_PLAYING:
            self.pending_inter = False
            self.state = self.STATE_INTER
            Audio.play('beep_01')

        # M5 双人 GAMEOVER 兜底: 两人皆命尽 → 结算
        if self.mode_coop and self.state == self.STATE_PLAYING:
            if all(p.input_dead for p in self.players):
                self.score = sum(p.score for p in self.players)
                self._record_run()
                self.state = self.STATE_GAMEOVER

    def _update_meteors(self, dt):
        if not ASSETS:
            return
        self.meteor_timer -= dt
        if self.meteor_timer <= 0 and len(self.meteors) < 4:
            self.meteor_timer = rand_range(3.0, 6.0)
            kind = random.choice(['meteor_big', 'meteor_med', 'meteor_med', 'meteor_small'])
            cfg = {'meteor_big': (34, 12), 'meteor_med': (20, 6), 'meteor_small': (12, 3)}[kind]
            self.meteors.append({
                'x': rand_range(30, SCREEN_W - 30), 'y': -60,
                'vy': rand_range(1.0, 2.2), 'vx': rand_range(-0.4, 0.4),
                'rot': rand_range(0, 360), 'vr': rand_range(-60, 60),
                'spr': kind, 'size': cfg[0], 'hp': cfg[1],
            })
        for m in self.meteors:
            m['y'] += m['vy'] * dt * 60
            m['x'] += m['vx'] * dt * 60
            m['rot'] += m['vr'] * dt
        self.meteors = [m for m in self.meteors
                        if m['y'] < SCREEN_H + 80 and m['hp'] > 0]

    def _draw_meteors(self):
        for m in self.meteors:
            spr = ASSETS.get(m['spr'])
            if not spr:
                continue
            rot = pygame.transform.rotate(spr, m['rot'])
            self.screen.blit(rot, rot.get_rect(center=(int(m['x']), int(m['y']))))

    def _boom(self, x, y, scale=1.0, big=False):
        src = ASSETS.get('boom2' if big else 'boom1')
        if not src:
            return
        d = max(8, int(128 * scale))
        self.booms.append({'x': x, 'y': y, 'big': big, 'd': d,
                           'i': 0, 't': 0, 'n': len(src)})

    def _boom_frames(self, big, d):
        key = (big, d)
        cached = self._boom_cache.get(key)
        if cached is None:
            src = ASSETS.get('boom2' if big else 'boom1') or []
            cached = [pygame.transform.smoothscale(f, (d, d)) for f in src]
            self._boom_cache[key] = cached
        return cached

    def _collisions(self):
        graze_radius = 30  # 擦弹判定半径

        # 玩家子弹 vs 敌机
        for b in self.bullets:
            if not b.is_player or b.dead:
                continue
            shooter = self.players[b.owner] if 0 <= b.owner < len(self.players) \
                else self.player
            for e in self.enemies:
                if e.dead:
                    continue
                dist = math.hypot(b.x - e.x, b.y - e.y)
                if dist < e.size + b.size:
                    killed = e.hit(b.damage)
                    if not b.pierce:
                        b.dead = True
                    if killed:
                        shooter.add_combo()
                        mult = min(10, 1 + shooter.combo // 3)
                        gained = e.score * mult
                        shooter.score += gained
                        self.popups.append({'x': e.x, 'y': e.y, 'txt': str(gained),
                                            'life': 0.7, 'color': YELLOW if mult > 1 else WHITE})
                        if e.kind == 'boss':
                            big_explosion(self.particles, e.x, e.y, 80)
                            self._boom(e.x, e.y, scale=1.8, big=True)
                            self.screen_shake = 0.8
                            self.screen_flash = 0.4
                            self.hitstop = 0.12
                            Audio.play('explosion_01')
                            for _ in range(3):
                                self.powerups.append(PowerUp(e.x + rand_range(-30, 30),
                                                           e.y + rand_range(-20, 20)))
                        else:
                            explosion(self.particles, e.x, e.y, e.color, 18, 7)
                            self._boom(e.x, e.y, scale=0.45 + e.size / 120.0)
                            self.screen_shake = max(self.screen_shake, 0.1)
                            Audio.play('explosion_02')
                            if random.random() < 0.18:
                                self.powerups.append(PowerUp(e.x, e.y))
                    else:
                        self.particles.append(Particle(b.x, b.y, WHITE, speed=2,
                                                      size=2, life=0.15))
                    if not b.pierce:
                        break

        # 玩家子弹 vs 陨石
        for b in self.bullets:
            if not b.is_player or b.dead:
                continue
            shooter = self.players[b.owner] if 0 <= b.owner < len(self.players) \
                else self.player
            for m in self.meteors:
                if m['hp'] <= 0:
                    continue
                if math.hypot(b.x - m['x'], b.y - m['y']) < m['size'] + b.size:
                    m['hp'] -= b.damage
                    if not b.pierce:
                        b.dead = True
                    if m['hp'] <= 0:
                        explosion(self.particles, m['x'], m['y'], ORANGE, 14, 6)
                        self._boom(m['x'], m['y'], scale=0.8)
                        Audio.play('explosion_02')
                        shooter.score += {'meteor_big': 50, 'meteor_med': 30,
                                          'meteor_small': 20}[m['spr']]
                    else:
                        self.particles.append(Particle(b.x, b.y, GRAY, speed=2,
                                                      size=2, life=0.15))
                    if not b.pierce:
                        break

        # 陨石撞玩家 (遍历所有 alive)
        for m in self.meteors:
            if m['hp'] <= 0:
                continue
            for p in self.players:
                if not p.alive or p.input_dead:
                    continue
                if math.hypot(m['x'] - p.x, m['y'] - p.y) \
                        < m['size'] * 0.7 + p.size * 0.5:
                    m['hp'] = 0
                    explosion(self.particles, m['x'], m['y'], ORANGE, 16, 6)
                    died = p.take_damage(1)
                    self.screen_shake = 0.3
                    if died:
                        big_explosion(self.particles, p.x, p.y, 30)
                        self._on_player_death(p)
                    break

        # 敌方子弹 vs 玩家 + 擦弹
        for b in self.bullets:
            if b.is_player or b.dead:
                continue
            for p in self.players:
                if not p.alive or p.input_dead:
                    continue
                dist = math.hypot(b.x - p.x, b.y - p.y)
                if dist < p.size * 0.5 + b.size:
                    b.dead = True
                    died = p.take_damage()
                    self.screen_shake = 0.25
                    explosion(self.particles, p.x, p.y, CYAN, 8, 4)
                    Audio.play('misc_03')
                    if died:
                        self.screen_shake = 0.6
                        self.screen_flash = 0.2
                        self.hitstop = 0.15
                        Audio.play('retro_explosion')
                        big_explosion(self.particles, p.x, p.y, 30)
                        self._boom(p.x, p.y, scale=2.0, big=True)
                        self._on_player_death(p)
                    break
                elif dist < graze_radius:
                    p.score += 10
                    p.graze_count += 1
                    if p.graze_count == 1:
                        self._toast('graze')
                    if random.random() < 0.3:
                        self.particles.append(Particle(b.x, b.y, WHITE, speed=1,
                                                      size=1.5, life=0.2))

        # 敌机撞玩家
        for e in self.enemies:
            if e.dead:
                continue
            for p in self.players:
                if not p.alive or p.input_dead:
                    continue
                dist = math.hypot(e.x - p.x, e.y - p.y)
                if dist < e.size * 0.7 + p.size * 0.5:
                    died = p.take_damage(2)
                    e.hit(8)
                    self.screen_shake = 0.35
                    explosion(self.particles, p.x, p.y, ORANGE, 12, 5)
                    if e.kind == 'kamikaze':
                        e.dead = True
                        big_explosion(self.particles, e.x, e.y, 25)
                        self.screen_shake = 0.5
                    if died:
                        big_explosion(self.particles, p.x, p.y, 30)
                        self._on_player_death(p)
                    break

        # 道具拾取 (谁碰到谁吃)
        for pu in self.powerups:
            if pu.dead:
                continue
            for p in self.players:
                if not p.alive or p.input_dead:
                    continue
                if math.hypot(pu.x - p.x, pu.y - p.y) < pu.size + p.size:
                    pu.dead = True
                    self._apply_powerup(pu.kind, p)
                    explosion(self.particles, p.x, p.y, pu.color, 8, 3)
                    Audio.play('retro_beep_04')
                    break

    def _on_player_death(self, p):
        """玩家本次命耗尽: 单人立即 GAMEOVER; 双人下若还有 lives 则 3s 后复活,
        lives<=0 则 input_dead=True(HUD 置灰, 输入失效), 两人皆 input_dead 由 _update 兜底"""
        if not self.mode_coop:
            if p.lives <= 0:
                self.score = sum(pp.score for pp in self.players)
                self._record_run()
                self.state = self.STATE_GAMEOVER
            return
        if p.lives <= 0:
            p.input_dead = True
            p.alive = False
            return
        # 尚有命: 3s 复活
        p.alive = False
        p.respawn_timer = 3.0

    def _on_boss_dead(self, e):
        if not CAMPAIGN['active']:
            return
        if self.wave_mgr.wave >= 20:
            self._victory()
            return
        self.pending_inter = True
        self.inter_stats = {
            'ch': e.chapter,
            'score': self.score - self.chapter_start_score,
            'hp': self.player.hp, 'max_hp': self.player.max_hp,
            'time': self.time - self.chapter_start_time,
        }

    def _victory(self):
        self.victory_stats = {
            'score': self.score,
            'time': self.time,
            'combo': self.max_combo,
            'graze': self.player.graze_count,
            'lives': self.player.lives,
        }
        self._record_run(cleared=True)
        self.state = self.STATE_VICTORY
        Audio.play('explosion_01')

    def _apply_powerup(self, kind, target=None):
        p = target if target is not None else self.player
        if kind == 'spread':
            p.shoot_level = min(4, p.shoot_level + 1)
        elif kind == 'missile_ammo':
            p.missile_ammo += 3
        elif kind == 'bomb':
            p.bombs = min(5, p.bombs + 1)
        elif kind == 'heal':
            p.hp = min(p.max_hp, p.hp + 2)
        elif kind == 'shield':
            p.shield_timer = 10.0
            self._toast('shield')
        elif kind == 'energy':
            p.energy = min(p.max_energy, p.energy + 40)

    # ===== 渲染 =====
    def _draw(self):
        amp = 5 if Config.get('shake') else 0
        sx = rand_range(-amp, amp) * self.screen_shake
        sy = rand_range(-amp, amp) * self.screen_shake

        self.screen.fill(DARK_BG)
        self.bg.draw(self.screen)

        if self.state == self.STATE_MENU:
            self._draw_menu()
        elif self.state in (self.STATE_PLAYING, self.STATE_PAUSED):
            self._draw_gameplay(sx, sy)
            self._draw_hud()
            self._draw_lowhp()
            self._draw_hint_bar()
            self._draw_toast()
            # M6 触控: 屏上按钮簇 (仅 PLAYING, 暂停时不画)
            if self.input.kind == 'touch' and self.state == self.STATE_PLAYING:
                self.input.draw_touch_ui(self.screen)
            if self.state == self.STATE_PAUSED:
                self._draw_pause_menu()
        elif self.state == self.STATE_GAMEOVER:
            self._draw_gameplay(sx, sy)
            self._draw_gameover()
        elif self.state == self.STATE_VICTORY:
            self._draw_gameplay(sx, sy)
            self._draw_victory()
        elif self.state == self.STATE_INTER:
            self._draw_gameplay(sx, sy)
            self._draw_inter()
        elif self.state == self.STATE_SHOP:
            self._draw_gameplay(sx, sy)
            self._draw_shop()
        elif self.state == self.STATE_SETTINGS:
            self._draw_settings()
        elif self.state == self.STATE_MODESEL:
            self._draw_list_screen('mode_title', self._mode_entries(),
                                   self.modesel_sel)
        elif self.state == self.STATE_DIFFSEL:
            self._draw_list_screen('diff_title', self._diff_entries(),
                                   self.diffsel_sel)
        elif self.state == self.STATE_HELP:
            self._draw_help()

        # M8 方向C: 暖纸暗角 (统一整幅画面)
        self.screen.blit(self._paper, (0, 0))

        # 屏幕闪白
        if self.screen_flash > 0:
            flash = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            flash.fill((255, 255, 255, int(self.screen_flash * 200)))
            self.screen.blit(flash, (0, 0))

        pygame.display.flip()

    def _draw_gameplay(self, sx, sy):
        for p in self.powerups:
            p.draw(self.screen)
        for e in self.enemies:
            e.draw(self.screen)
        self._draw_meteors()
        for b in self.bullets:
            b.draw(self.screen)
        if self.state != self.STATE_GAMEOVER:
            for p in self.players:
                spr = self.sprites['player'] if p.idx == 0 \
                    else self.sprites.get('player2', self.sprites['player'])
                p.draw(self.screen, spr)
        for p in self.particles:
            p.draw(self.screen)

        # 序列帧爆炸
        for b in self.booms:
            frames = self._boom_frames(b['big'], b['d'])
            i = min(b['i'], len(frames) - 1)
            frame = frames[i]
            self.screen.blit(frame, frame.get_rect(center=(int(b['x']), int(b['y']))))

        # 飘分
        for pp in self.popups:
            surf = self.font_s.render(pp['txt'], True, pp['color'])
            surf.set_alpha(int(255 * min(1, pp['life'] / 0.4)))
            self.screen.blit(surf, surf.get_rect(center=(int(pp['x']), int(pp['y']))))

        # 波次横幅
        if self.wave_mgr.banner_timer > 0:
            alpha = min(1.0, self.wave_mgr.banner_timer / 0.5)
            is_boss = (self.wave_mgr.wave % 5 == 0)
            txt = T('banner_boss', self.wave_mgr.wave) if is_boss else T('banner_wave', self.wave_mgr.wave)
            color = RED if is_boss else YELLOW
            surf = self.font_l.render(txt, True, color)
            surf.set_alpha(int(255 * alpha))
            self.screen.blit(surf, surf.get_rect(center=(SCREEN_W // 2, SCREEN_H // 3)))

    def _draw_stage_bar(self):
        """顶居中关卡显示: 战役章/波 + 5 段进度; 无尽第 N 波; Boss 波红色"""
        w = self.wave_mgr.wave or 1
        boss_wave = (w % 5 == 0)
        if boss_wave:
            txt, color = T('stage_boss'), INK_ROSE
        elif self.mode == 'campaign':
            ch = (w - 1) // 5 + 1
            wi = (w - 1) % 5 + 1
            txt, color = T('stage_campaign', ch, wi), INK
        else:
            txt, color = T('stage_endless', w), INK
        s = self.font_s.render(txt, True, color)
        plaque_blit(self.screen, s, center=(SCREEN_W // 2, 18))
        if self.mode == 'campaign':
            wi = (w - 1) % 5 + 1
            seg_w, gap = 22, 5
            total = 5 * seg_w + 4 * gap
            x0 = SCREEN_W // 2 - total // 2
            for i in range(5):
                x = x0 + i * (seg_w + gap)
                if boss_wave:
                    c = INK_ROSE
                elif i < wi - 1:
                    c = INK_INDIGO
                elif i == wi - 1:
                    c = INK_GOLD
                else:
                    c = (214, 204, 188)
                pygame.draw.rect(self.screen, c, (x, 40, seg_w, 4))

    @staticmethod
    def _make_vignette(th=70):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 0))
        for i in range(th):
            f = (1 - i / th) ** 1.5
            c = (200, 30, 40, int(160 * f))
            pygame.draw.rect(ov, c, (0, i, SCREEN_W, 1))
            pygame.draw.rect(ov, c, (0, SCREEN_H - 1 - i, SCREEN_W, 1))
            pygame.draw.rect(ov, c, (i, 0, 1, SCREEN_H))
            pygame.draw.rect(ov, c, (SCREEN_W - 1 - i, 0, 1, SCREEN_H))
        return ov

    @staticmethod
    def _make_paper(th=90):
        """M8 方向C: 暖纸暗角 — 边缘暖褐轻压暗, 中心透亮, 统一整幅画面"""
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 0))
        for i in range(th):
            f = (1 - i / th) ** 2.0
            c = (122, 92, 70, int(52 * f))
            pygame.draw.rect(ov, c, (0, i, SCREEN_W, 1))
            pygame.draw.rect(ov, c, (0, SCREEN_H - 1 - i, SCREEN_W, 1))
            pygame.draw.rect(ov, c, (i, 0, 1, SCREEN_H))
            pygame.draw.rect(ov, c, (SCREEN_W - 1 - i, 0, 1, SCREEN_H))
        return ov

    def _draw_lowhp(self):
        if self.state != self.STATE_PLAYING:
            return
        if not any(p.alive and not p.input_dead and p.hp <= 2 for p in self.players):
            return
        pulse = 0.5 + 0.5 * math.sin(self.time * 6)
        self._vignette.set_alpha(int(90 + 110 * pulse))
        self.screen.blit(self._vignette, (0, 0))

    def _draw_hint_bar(self):
        if self.hint_timer <= 0 or self.state != self.STATE_PLAYING:
            return
        alpha = 255 if self.hint_timer > 2 else int(255 * self.hint_timer / 2)
        if self.mode_coop:
            key = 'hint_coop'
        else:
            key = 'hint_android' if self.input.kind == 'touch' else 'hint_pc'
        txt = T(key)
        f = self.font_xs
        parts = txt.split(' · ')
        lines = [txt] if f.size(txt)[0] <= SCREEN_W - 48 else \
            [' · '.join(parts[:2]), ' · '.join(parts[2:])]
        w = max(f.size(ln)[0] for ln in lines) + 40
        h = 10 + len(lines) * 20
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        ov.fill((9, 25, 43, 225))
        ov.set_alpha(alpha)
        y = SCREEN_H - 96 - (len(lines) - 1) * 20
        self.screen.blit(ov, (SCREEN_W // 2 - w // 2, y))
        for i, ln in enumerate(lines):
            s = f.render(ln, True, INK)
            s.set_alpha(alpha)
            self.screen.blit(s, (SCREEN_W // 2 - s.get_width() // 2, y + 6 + i * 20))

    def _draw_toast(self):
        if not self.toast or self.state != self.STATE_PLAYING:
            return
        t = self.toast['t']
        slide = min(1.0, (3.0 - t) / 0.3)
        y = int(-40 + slide * 100)
        alpha = 255 if t > 0.4 else int(255 * t / 0.4)
        s = self.font_s.render(T('toast_' + self.toast['key']), True, INK_GOLD)
        w = s.get_width() + 36
        ov = pygame.Surface((w, 32), pygame.SRCALPHA)
        ov.fill((9, 25, 43, 235))
        ov.set_alpha(alpha)
        self.screen.blit(ov, (SCREEN_W // 2 - w // 2, y))
        s.set_alpha(alpha)
        self.screen.blit(s, (SCREEN_W // 2 - s.get_width() // 2, y + 7))

    def _draw_player_panel(self, p, side):
        """单个玩家的状态面板: HP/能量/命数/炸弹/武器/combo
        side='left' 靠左下, 'right' 靠右下; 命尽(input_dead)时整体置灰"""
        grey = p.input_dead
        bw = 110
        if side == 'left':
            bx = 12
            life_x0 = 132
            bomb_x0 = None
            wx = 12
            combo_cx = None
        else:
            bx = SCREEN_W - 12 - bw
            life_x0 = bx + bw + 8
            bomb_x0 = SCREEN_W - 20
            wx = SCREEN_W - 12
            combo_cx = None
        by = SCREEN_H - 28

        # HP 条
        pygame.draw.rect(self.screen, (238, 230, 214), (bx, by, bw, 10))
        if not grey:
            ratio = p.hp / p.max_hp
            color = INK_LEAF if ratio > 0.5 else INK_GOLD if ratio > 0.25 else INK_ROSE
            pygame.draw.rect(self.screen, color, (bx, by, int(bw * ratio), 10))
        pygame.draw.rect(self.screen, INK_SOFT, (bx, by, bw, 10), 1)

        # 能量条
        ey = by - 14
        pygame.draw.rect(self.screen, (238, 230, 214), (bx, ey, bw, 6))
        if not grey:
            pygame.draw.rect(self.screen, INK_INDIGO,
                             (bx, ey, int(bw * p.energy / p.max_energy), 6))

        # 命数图标
        life_key = 'life_p2' if p.idx == 1 else 'life_p1'
        life = self.sprites.get(life_key)
        for i in range(p.lives):
            if life:
                lx = life_x0 + i * (life.get_width() + 4) \
                    if side == 'left' else life_x0 - (i + 1) * (life.get_width() + 4)
                self.screen.blit(life, (lx, SCREEN_H - 32))
            else:
                mini = pygame.transform.scale(
                    self.sprites['player2' if p.idx == 1 else 'player'], (14, 14))
                lx = life_x0 + i * 18 if side == 'left' \
                    else life_x0 - (i + 1) * 18
                self.screen.blit(mini, (lx, SCREEN_H - 30))

        # 炸弹 (右下角玩家画在右侧, 左下角玩家画在左侧靠命数右边)
        if bomb_x0 is not None:
            for i in range(p.bombs):
                cx = bomb_x0 - i * 20
                pygame.draw.circle(self.screen, INK_ROSE if not grey else (150, 144, 138),
                                   (cx, SCREEN_H - 22), 7)
                pygame.draw.circle(self.screen, CREAM if not grey else (200, 194, 188),
                                   (cx, SCREEN_H - 22), 3)
        else:
            # 左下玩家: 炸弹画在命数下方一排
            for i in range(p.bombs):
                cx = 132 + i * 20
                pygame.draw.circle(self.screen, INK_ROSE if not grey else (150, 144, 138),
                                   (cx, SCREEN_H - 52), 6)
                pygame.draw.circle(self.screen, CREAM if not grey else (200, 194, 188),
                                   (cx, SCREEN_H - 52), 2)

        # 武器名 (左上 / 右上) — 墨水映射
        WPN_INK = {WPN_VULCAN: INK_INDIGO, WPN_LASER: INK_LEAF, WPN_MISSILE: INK_ROSE}
        wcolor = WPN_INK.get(p.weapon, INK) if not grey else (150, 144, 138)
        wn = self.font_s.render(T('hud_weapon', T('wpn%d' % p.weapon)), True, wcolor)
        if side == 'left':
            plaque_blit(self.screen, wn, topleft=(wx, 20))
            if p.weapon == WPN_MISSILE:
                ma = self.font_s.render(f"x{p.missile_ammo}", True,
                                        INK_ROSE if not grey else (150, 144, 138))
                plaque_blit(self.screen, ma, topleft=(wx, 48), pad=(7, 3))
        else:
            plaque_blit(self.screen, wn, topleft=(wx - wn.get_width() - 20, 20))
            if p.weapon == WPN_MISSILE:
                ma = self.font_s.render(f"x{p.missile_ammo}", True,
                                        INK_ROSE if not grey else (150, 144, 138))
                plaque_blit(self.screen, ma,
                            topleft=(wx - ma.get_width() - 14, 48), pad=(7, 3))

        # 命尽标记
        if grey:
            tag = self.font_s.render('命尽', True, INK_SOFT)
            tx = bx + bw // 2 - tag.get_width() // 2
            self.screen.blit(tag, (tx, by - 34))

    def _draw_hud(self):
        if self.mode_coop:
            # 双人: P1 左下, P2 右下
            self._draw_player_panel(self.players[0], 'left')
            if len(self.players) > 1:
                self._draw_player_panel(self.players[1], 'right')
            # 分数双列置顶 + 中央队伍总分
            p1s = self.font_m.render(f"{self.players[0].score:,}", True, INK_INDIGO)
            plaque_blit(self.screen, p1s, topleft=(12, 6))
            if len(self.players) > 1:
                p2s = self.font_m.render(f"{self.players[1].score:,}", True, INK_ROSE)
                plaque_blit(self.screen, p2s,
                            topleft=(SCREEN_W - p2s.get_width() - 32, 6))
            team = self.font_s.render(f"队伍 {self.score:,}", True, INK)
            self.screen.blit(team, team.get_rect(center=(SCREEN_W // 2, 44)))
            # combo: 任一玩家 >=3 就在底部中央显示其倍率(取较高者)
            best = max((p for p in self.players if p.alive and not p.input_dead),
                       key=lambda p: p.combo, default=None)
            if best and best.combo >= 3:
                mult = min(10, 1 + best.combo // 3)
                cs = self.font_s.render(T('hud_combo', mult), True, INK_GOLD)
                self.screen.blit(cs, (SCREEN_W // 2 - cs.get_width() // 2,
                                      SCREEN_H - 50))
            # 擦弹: 两人合计
            total_graze = sum(p.graze_count for p in self.players)
            if total_graze > 0:
                gs = self.font_s.render(T('hud_graze', total_graze), True, INK_SOFT)
                self.screen.blit(gs, (SCREEN_W // 2 - gs.get_width() // 2, 62))
        else:
            p = self.player
            self._draw_player_panel(p, 'left')
            # 炸弹画在右下 (单人既有布局)
            for i in range(p.bombs):
                pygame.draw.circle(self.screen, INK_ROSE,
                                   (SCREEN_W - 20 - i * 20, SCREEN_H - 22), 7)
                pygame.draw.circle(self.screen, CREAM,
                                   (SCREEN_W - 20 - i * 20, SCREEN_H - 22), 3)
            # 分数右上 (羊皮纸牌匾)
            s = self.font_m.render(f"{self.score:,}", True, INK)
            plaque_blit(self.screen, s, topleft=(SCREEN_W - s.get_width() - 32, 6))
            # combo 底部中央
            if p.combo >= 3:
                mult = min(10, 1 + p.combo // 3)
                cs = self.font_s.render(T('hud_combo', mult), True, INK_GOLD)
                self.screen.blit(cs, (SCREEN_W // 2 - cs.get_width() // 2,
                                      SCREEN_H - 50))
            # 擦弹右上
            if p.graze_count > 0:
                gs = self.font_s.render(T('hud_graze', p.graze_count), True, INK_SOFT)
                self.screen.blit(gs, (SCREEN_W - gs.get_width() - 12, 34))

        # 关卡显示(顶居中) + 暂停提示(右上淡字) — 全模式共用
        self._draw_stage_bar()
        ph = self.font_xs.render(T('hud_pause_hint'), True, INK_SOFT)
        self.screen.blit(ph, (SCREEN_W - ph.get_width() - 12, 56))

    def _draw_menu(self):
        t = self.font_l.render("SKY STRIKE", True, INK_INDIGO)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, 150)))
        t2 = self.font_m.render(T('menu_sub'), True, INK)
        self.screen.blit(t2, t2.get_rect(center=(SCREEN_W // 2, 205)))

        entries = [(T('menu_start'), None), (T('menu_help'), None),
                   (T('menu_settings'), None), (T('menu_quit'), None)]
        self._draw_list_menu(entries, self.menu_sel, y0=300, step=62, on_dark=False)

        # 各模式最高分
        sv = SaveData.data
        lines = [T('menu_high', f"{sv['endless']['high']:,}")]
        camp = sv['campaign']
        if camp['cleared']:
            lines.append(T('mode_campaign') + ' · ' + ('已通关' if Fonts.cjk() else 'CLEARED')
                         + f" ({camp['high']:,})")
        elif camp['best_wave'] > 0:
            lines.append(T('mode_campaign') + f" · {camp['best_wave']}")
        if sv['coop']['high'] > 0:
            lines.append(T('mode_coop') + f" · {sv['coop']['high']:,}")
        for i, ln in enumerate(lines):
            s = self.font_xs.render(ln, True, INK_GOLD if i == 0 else INK_SOFT)
            self.screen.blit(s, s.get_rect(center=(SCREEN_W // 2, SCREEN_H - 70 + i * 20)))

    def menu_rect(self, i):
        """主菜单第 i 条目命中矩形 (与 _draw_list_menu y0=300 step=62 h=50 一致)"""
        y = 300 + i * 62
        return pygame.Rect(70, y - 6, SCREEN_W - 140, 50)

    def mode_rect(self, i):
        """模式/难度选择第 i 条目 (与 _draw_list_screen y0=250 step=88 h=76 一致)"""
        y = 250 + i * 88
        return pygame.Rect(70, y - 6, SCREEN_W - 140, 76)

    diff_rect = mode_rect

    def pause_rect(self, i):
        """暂停菜单第 i 条目 (与 _draw_pause_menu y0=256 step=62 h=50 一致)"""
        y = 256 + i * 62
        return pygame.Rect(70, y - 6, SCREEN_W - 140, 50)

    def shop_rect(self, i):
        """商店第 i 条目 (与 _draw_shop y=200+i*65, 条高 55 一致)"""
        y = 200 + i * 65
        return pygame.Rect(50, y - 5, SCREEN_W - 100, 55)

    def settings_rect(self, i):
        """设置页第 i 行 (与 _draw_settings y=270+i*62, 行高 48 一致)"""
        y = 270 + i * 62
        return pygame.Rect(60, y - 8, SCREEN_W - 120, 48)

    def settings_bar_rect(self, i):
        """设置页第 i 行音量条命中区 (10 格, 每格 12px, 起点 SCREEN_W-200)"""
        y = 270 + i * 62
        return pygame.Rect(SCREEN_W - 200, y + 6, 120, 16)

    def Tt(self, key):
        """M6: 触控时优先取 <key>_touch 变体文案, 无则回退原 key."""
        if self.input.kind == 'touch':
            k = key + '_touch'
            if k in TEXT:
                return T(k)
        return T(key)

    def _draw_list_menu(self, entries, sel, y0=300, step=64, on_dark=True):
        # on_dark=True: 暗 veil 上纸白字; False: 亮天空上墨水字
        sel_fill = (72, 64, 58) if on_dark else (17, 48, 70)
        sel_line = CREAM if on_dark else INK_INDIGO
        c_sel = CREAM if on_dark else INK
        c_dim = (206, 196, 186) if on_dark else INK_SOFT
        c_desc = (190, 180, 170) if on_dark else INK_SOFT
        for i, (label, desc) in enumerate(entries):
            h = 76 if desc else 50
            y = y0 + i * step
            if i == sel:
                pygame.draw.rect(self.screen, sel_fill, (70, y - 6, SCREEN_W - 140, h))
                pygame.draw.rect(self.screen, sel_line, (70, y - 6, SCREEN_W - 140, h), 2)
                pygame.draw.polygon(self.screen, sel_line,
                                    [(78, y + 12), (78, y + 26), (90, y + 19)])
            c = c_sel if i == sel else c_dim
            ls = self.font_m.render(label, True, c)
            self.screen.blit(ls, (98, y))
            if desc:
                ds = self.font_xs.render(desc, True, c_desc)
                self.screen.blit(ds, (98, y + 42))

    def _draw_list_screen(self, title_key, entries, sel):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 150))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T(title_key), True, CREAM)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, 170)))
        self._draw_list_menu(entries, sel, y0=250, step=88)
        hint = self.font_xs.render(self.Tt('sel_hint'), True, (206, 196, 186))
        self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, SCREEN_H - 60)))

    def _mode_entries(self):
        # M6 触控: 安卓只支持单人单机 (战役+无尽), 隐藏双人合作
        if self.input.kind == 'touch':
            return [(T('mode_campaign'), T('mode_campaign_d')),
                    (T('mode_endless'), T('mode_endless_d'))]
        return [(T('mode_campaign'), T('mode_campaign_d')),
                (T('mode_endless'), T('mode_endless_d')),
                (T('mode_coop'), T('mode_coop_d'))]

    def _diff_entries(self):
        return [(T('diff_easy'), T('diff_easy_d')),
                (T('diff_normal'), T('diff_normal_d')),
                (T('diff_hell'), T('diff_hell_d'))]

    def _draw_pause_menu(self):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 160))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T('pause_title'), True, CREAM)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, 180)))
        entries = [(T(k), None) for k in ('pause_resume', 'pause_restart',
                                          'pause_help', 'pause_settings',
                                          'pause_quit')]
        self._draw_list_menu(entries, self.pause_sel, y0=256, step=62)
        hint = self.font_xs.render(self.Tt('sel_hint'), True, (206, 196, 186))
        self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, SCREEN_H - 60)))

    def _draw_help(self):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 200))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T('help_title'), True, CREAM)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, 130)))
        keys = ['help_move', 'help_wpn', 'help_wpn2', 'help_bomb', 'help_pause',
                '', 'help_graze', 'help_combo', 'help_shop', 'help_coop']
        if self.input.kind == 'touch':
            keys = keys[:-1]   # 触控无双人
        y = 230
        for k in keys:
            if k:
                s = self.font_s.render(self.Tt(k), True, (226, 218, 208))
                self.screen.blit(s, s.get_rect(center=(SCREEN_W // 2, y)))
            y += 36
        if int(self.time * 2) % 2 == 0:
            b = self.font_s.render(self.Tt('help_back'), True, (222, 182, 112))
            self.screen.blit(b, b.get_rect(center=(SCREEN_W // 2, SCREEN_H - 80)))

    def _draw_overlay(self, title, color, subtitle=""):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 160))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(title, True, color)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 - 20)))
        if subtitle:
            s = self.font_s.render(subtitle, True, (206, 196, 186))
            self.screen.blit(s, s.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 + 30)))

    def _draw_gameover(self):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 180))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T('go_title'), True, (226, 120, 108))
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, SCREEN_H // 3)))
        s = self.font_m.render(T('go_score', f"{self.score:,}"), True, CREAM)
        self.screen.blit(s, s.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 - 20)))
        if self.mode == 'campaign':
            wv = self.wave_mgr.wave or 1
            w = self.font_m.render(T('go_reach', (wv - 1) // 5 + 1, (wv - 1) % 5 + 1),
                                   True, (222, 182, 112))
        else:
            w = self.font_m.render(T('go_wave', self.wave_mgr.wave), True, (222, 182, 112))
        self.screen.blit(w, w.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 + 15)))
        graze_total = sum(p.graze_count for p in self.players)
        g = self.font_s.render(T('go_graze', graze_total), True, (206, 196, 186))
        self.screen.blit(g, g.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 + 45)))
        if self.mode_coop and len(self.players) > 1:
            split = self.font_s.render(
                f"P1 {self.players[0].score:,}   P2 {self.players[1].score:,}",
                True, (206, 196, 186))
            self.screen.blit(split, split.get_rect(center=(SCREEN_W // 2,
                                                           SCREEN_H // 2 + 70)))
        if self.new_record:
            nr = self.font_m.render(T('go_new'), True, (222, 182, 112))
            self.screen.blit(nr, nr.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 + 100)))
        if int(self.time * 2) % 2 == 0:
            r = self.font_s.render(self.Tt('go_restart'), True, (206, 196, 186))
            self.screen.blit(r, r.get_rect(center=(SCREEN_W // 2, SCREEN_H * 0.75)))

    @staticmethod
    def _fmt_time(t):
        return int(t // 60), int(t % 60)

    def _draw_inter(self):
        st = self.inter_stats or {'ch': 1, 'score': 0, 'hp': 0, 'max_hp': 6, 'time': 0}
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 180))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T('inter_title', st['ch']), True, CREAM)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, SCREEN_H // 3)))
        m, s = self._fmt_time(st['time'])
        lines = [T('inter_score', f"{st['score']:,}"),
                 T('inter_hp', st['hp'], st['max_hp']),
                 T('inter_time', m, s)]
        for i, ln in enumerate(lines):
            surf = self.font_m.render(ln, True, CREAM)
            self.screen.blit(surf, surf.get_rect(
                center=(SCREEN_W // 2, SCREEN_H // 2 - 10 + i * 40)))
        if int(self.time * 2) % 2 == 0:
            h = self.font_s.render(self.Tt('inter_hint'), True, (222, 182, 112))
            self.screen.blit(h, h.get_rect(center=(SCREEN_W // 2, SCREEN_H * 0.78)))

    def _draw_victory(self):
        st = self.victory_stats or {'score': 0, 'time': 0, 'combo': 0,
                                    'graze': 0, 'lives': 0}
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 190))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T('victory_title'), True, (222, 182, 112))
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, 170)))
        sub = self.font_m.render(T('victory_sub'), True, CREAM)
        self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 225)))
        m, s = self._fmt_time(st['time'])
        lines = [T('st_score', f"{st['score']:,}"),
                 T('st_time', m, s),
                 T('st_combo', st['combo']),
                 T('st_graze', st['graze']),
                 T('st_lives', st['lives'])]
        for i, ln in enumerate(lines):
            surf = self.font_s.render(ln, True, CREAM)
            self.screen.blit(surf, surf.get_rect(
                center=(SCREEN_W // 2, 290 + i * 34)))
        if self.new_record:
            nr = self.font_m.render(T('go_new'), True, (222, 182, 112))
            self.screen.blit(nr, nr.get_rect(center=(SCREEN_W // 2, 480)))
        if int(self.time * 2) % 2 == 0:
            h = self.font_s.render(self.Tt('again_hint'), True, (206, 196, 186))
            self.screen.blit(h, h.get_rect(center=(SCREEN_W // 2, SCREEN_H - 70)))

    def _draw_shop(self):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 200))
        self.screen.blit(ov, (0, 0))

        title = self.font_m.render(T('shop_title'), True, (222, 182, 112))
        self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 120)))
        score_label = T('shop_score', f"{self.score:,}")
        if self.mode_coop:
            score_label = '队伍 ' + score_label
        score_s = self.font_s.render(score_label, True, CREAM)
        self.screen.blit(score_s, score_s.get_rect(center=(SCREEN_W // 2, 155)))

        for i, item in enumerate(Shop.ITEMS):
            y = 200 + i * 65
            selected = (i == self.shop.selected)
            cost = self.shop.cost_of(i, coop=self.mode_coop)
            affordable = self.score >= cost

            # 背景条
            if selected:
                pygame.draw.rect(self.screen, (72, 64, 58), (50, y - 5, SCREEN_W - 100, 55))
                pygame.draw.rect(self.screen, CREAM, (50, y - 5, SCREEN_W - 100, 55), 2)

            # 名字
            name_color = CREAM if selected else (206, 196, 186)
            ns = self.font_m.render(T(item['name']), True, name_color)
            self.screen.blit(ns, (70, y))

            # 价格
            if cost > 0:
                pc = (222, 182, 112) if affordable else (226, 120, 108)
                ps = self.font_s.render(f"{cost:,}", True, pc)
                self.screen.blit(ps, (SCREEN_W - 70 - ps.get_width(), y + 5))

            # 描述
            ds = self.font_s.render(T(item['desc']), True, (190, 180, 170))
            self.screen.blit(ds, (70, y + 26))

        hint = self.font_s.render(self.Tt('shop_hint'), True, (206, 196, 186))
        self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, SCREEN_H - 60)))

    def _draw_settings(self):
        ov = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        ov.fill((58, 52, 48, 190))
        self.screen.blit(ov, (0, 0))
        t = self.font_l.render(T('set_title'), True, CREAM)
        self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, 150)))
        sub = self.font_xs.render(self.Tt('set_sub'), True, (206, 196, 186))
        self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 200)))

        rows = [('set_master', Config.get('vol_master')),
                ('set_music', Config.get('vol_music')),
                ('set_sfx', Config.get('vol_sfx')),
                ('set_shake', T('set_on') if Config.get('shake') else T('set_off')),
                ('set_back', None)]
        for i, (key, val) in enumerate(rows):
            y = 270 + i * 62
            sel = (i == self.settings_sel)
            if sel:
                pygame.draw.rect(self.screen, (72, 64, 58), (60, y - 8, SCREEN_W - 120, 48))
                pygame.draw.rect(self.screen, CREAM, (60, y - 8, SCREEN_W - 120, 48), 2)
            lc = CREAM if sel else (206, 196, 186)
            ls = self.font_m.render(T(key), True, lc)
            self.screen.blit(ls, (80, y))
            if val is None:
                continue
            if isinstance(val, int):
                # 10 格音量条
                bx = SCREEN_W - 80 - 120
                for seg in range(10):
                    x = bx + seg * 12
                    on = seg < val
                    pygame.draw.rect(self.screen,
                                     (222, 182, 112) if on else (96, 88, 80), (x, y + 6, 9, 16))
                vs = self.font_xs.render(str(val), True, lc)
                self.screen.blit(vs, (SCREEN_W - 72, y + 6))
            else:
                vs = self.font_m.render(val, True,
                                        (150, 180, 140) if Config.get('shake') else (226, 120, 108))
                self.screen.blit(vs, (SCREEN_W - 80 - vs.get_width(), y))


async def main():
    game = Game()
    game._draw()
    if sys.platform == "emscripten":
        import platform
        platform.window.skyState("ready")
    await game.run()


if __name__ == '__main__':
    asyncio.run(main())
